/**
 *   @file       AD7616.cpp
 *   @brief      Source file for AD7616 ADC
 *   @author     Cristian Deenen - Mesoscale Chemical Systems - University of Twente
 *   @device     Analog Control Board - Rev. 1.0
 *   @date       04-10-2018
 *
 * Library for the Analog Devices AD7616, 16-channel DAS with 16-bit, bipolar input, dual simultaneous sampling ADC. 
 * Configured for use on the Analog Control Board Rev. 1.0
 */


 
#include "mbed.h"
#include "AD7616.h"
#include "main.h"
//#include "MODSERIAL.h"

# define CONFIGURATION_REG  0x02
# define CHANNEL_REG        0x03
# define SPAN_A1_REG        0x04
# define SPAN_A2_REG        0x05
# define SPAN_B1_REG        0x06
# define SPAN_B2_REG        0x07

#define CH0 0
#define CH1 1
#define CH2 2
#define CH3 3
#define CH4 4
#define CH5 5
#define CH6 6
#define CH7 7
#define CH8 7
#define CH9 6
#define CH10 5
#define CH11 4
#define CH12 3
#define CH13 2
#define CH14 1
#define CH15 0

#define MOSI    P1_24
#define MISO    P1_23
#define SCK     P1_20
#define CS      P3_25
#define BUSY    P1_18
#define CONVST  P1_19
#define RESET   P1_25

//Serial pcADC(USBTX, USBRX);
SPI spiADC(MOSI, MISO, SCK); // mosi, miso, sclk
DigitalOut csADC(CS);      //chip select
DigitalIn busy(BUSY);
DigitalOut convst(CONVST);
DigitalOut Reset(RESET);

Timer busyTimer;                                                                //Timer to monitor timeout for the busy signal

////////////////////////////////////////////////////////////////////////////////
//Constructor
////////////////////////////////////////////////////////////////////////////////
AD7616::AD7616() {
    for (int i=0; i<16; i++) {
        calSettings[i][0] = 1;                                                  //Set calA to 1
        calSettings[i][1] = 0;                                                  //Set calB to 0
        spanSettings[i] = 2;                                                    //Set span to +-10V
        interruptMode[i] = 0;
        interruptState[i] = 0;                                                             //Stores enable state of summation for each analog input channel
        sumSource[i] = 0;                                                       //Stores source channel for the analog input sum (0-7 = analog outputs, 8-23 = analog input-8)
        sumFactor[i] = 0; 
    }
    interruptEnable = 0;
    oversampling = 0;
    sdef = 0;
    bursten = 0;
    seqen = 0;
    statusen = 0;
    crcen = 0;
    sumEn = 0;
}

////////////////////////////////////////////////////////////////////////////////
//Initialization
////////////////////////////////////////////////////////////////////////////////
void AD7616::initialize(){
    Reset = 0;
    csADC = 1;
    convst = 0;
    wait(0.1);
    Reset = 1;
    for (int i=0; i<16; i++) {
        setSpan(i, spanSettings[i]);
        setCalibration(i, calSettings[i][0], calSettings[i][1]);
        setOversampling(oversampling);
    }
}

////////////////////////////////////////////////////////////////////////////////
//Measurement functions
////////////////////////////////////////////////////////////////////////////////

/* This function will return the measured value on the selected channel, after applying the calibration values.
 * The AD7616 has 2 independent 8 channel ADCs. Data is received over SPI, using 32 bit words (16 bits per channel).
 * Each time data is requested, data is received from both ADCs. To get the correct channel, the channel register must be set.
 * The channel register is 8 bits long, 4 bits for each ADC, where the 4 bits indicate the selected channel on that specific ADC.
 * The internal channel number on the AD7616 does not correspond with the channel numbers on the ACB, so this needs to be corrected.
 *
 * Procedure for reading a measurement:
 *      -Find the correct channel and ADC
 *      -Set channel register for both ADCs to the same corrected chanel
 *      -Set CONVST pin HIGH to initiate the conversion process
 *      -Wait for the BUSY pin to go HIGH (start of conversion)
 *      -Wait for the BUSY pin to go LOW (conversion is complete)
 *      -Set CS LOW
 *      -Read 32 bits (16 bits for each channel set in the channel register)
 *      -Set CS HIGH
 *      -Convert the 16 bit integer to a float
 *      -Apply calibration values
 *      -Return correct value
 */
float AD7616::getMeasurement(uint8_t channel) {
    uint8_t correctChannel;                                                     //Variable to store the corrected channel
    bool selectedADC;                                                           //Variable to store the selected ADC
    channelCorrector(channel, correctChannel, selectedADC);                     //Find the correct ADC and channel                         
    setRegister(CHANNEL_REG,(correctChannel<<4)|correctChannel);                //Set the channel register on the AD7616 for both ADCs to correctChannel
    busyTimer.start();
    busyTimer.reset();                                                          //Start and reset the timer for the busy timeout
    convst = 1;                                                                 //Start conversion
    convst = 0;
    while(1) {
        if (busy) {                                                             //Wait until the busy pin goes high
            while(1) {
                if (busy == 0) break;                                           //Continue if the busy pin goes low
                if (busyTimer.read_us() > 250) {                                //If busy pin doesn't go down after 250us, the timeout will be triggered
                    busyTimer.stop();
                    convst = 0;
                    Reset = 0;                                                  //Reset the AD7616
                    Reset = 1;
                    message("AD7616 BUSY timeout triggered\n");
                    return 0;
                }
            }
            break;
        }
        else if (busyTimer.read_us() > 250) {                                   //If busy is not high within 250us, the timeout will be triggered
            busyTimer.stop();
            convst = 0;
            Reset = 0;                                                          //Reset the AD7616
            Reset = 1;
            message("BUSY timeout triggered\n");
            return 0;
        }
    }
    busyTimer.stop();
    int16_t val = readMeasurement(selectedADC);                                 //Read the measurements from the AD7616 and return the measurement of the selected ADC
    
    busyTimer.reset();
    convst = 1;                         
    convst = 0;
    while(1) {
        if (busy) {                                                             //Wait until the busy pin goes high
            while(1) {
                if (busy == 0) break;                                           //Continue if the busy pin goes low
                if (busyTimer.read_us() > 250) {                                //If busy pin doesn't go down after 250us, the timeout will be triggered
                    busyTimer.stop();
                    convst = 0;
                    Reset = 0;                                                  //Reset the AD7616
                    Reset = 1;
                    message("BUSY timeout triggered\n");
                    return 0;
                }
            }
            break;
        }
        else if (busyTimer.read_us() > 250) {                                   //If busy is not high within 250us, the timeout will be triggered
            busyTimer.stop();
            convst = 0;
            Reset = 0;                                                          //Reset the AD7616
            Reset = 1;
            message("BUSY timeout triggered\n");
            return 0;
        }
    }
    
    val = readMeasurement(selectedADC); 
    
    float measured = IntToFloat(spanSettings[channel], val);                    //Convert the measurement from a 16 bit integer to a float
    float A, B;                                                                 //Variables to store the calibration values
    getCalibration(channel,A,B);                                                //Get the calibration values
    float output = A*measured + B;                                              //Apply calibration
    
    if (getSumEn(channel)){
        uint8_t sumSourceCh = getSumCh(channel);
        float sumMeas = 0;
        if (sumSourceCh > 7) {  //input ch
            sumSourceCh -= 8;
            if (sumSourceCh != channel) sumMeas = getMeasurement(sumSourceCh);
        }
        else {
            //sumMeas = 
        }
        output += sumMeas*getSumFactor(channel);
    }
    
    
    
    return output;                                                              //Return the calibrated value
    
    
    
    
    
}

////////////////////////////////////////////////////////////////////////////////
//Input span functions
////////////////////////////////////////////////////////////////////////////////
/*Span settings
 * To input span of each channel on the AD7616 is determined by 4 8-bit registers, where each register contains the span of 4 channels, each being 2 bits long.
 * The span can be set for all channels, or for a single channel.
 * All span settings are internally (on the ACB) stored on a 16 element long array.
*/

void AD7616::updateSpanAll() {
    setRegister(SPAN_B1_REG,((spanSettings[3]+1)<<6)|((spanSettings[2]+1)<<4)|((spanSettings[1]+1)<<2)|(spanSettings[0]+1));
    setRegister(SPAN_B2_REG,((spanSettings[7]+1)<<6)|((spanSettings[6]+1)<<4)|((spanSettings[5]+1)<<2)|(spanSettings[4]+1));
    setRegister(SPAN_A2_REG,((spanSettings[8]+1)<<6)|((spanSettings[9]+1)<<4)|((spanSettings[10]+1)<<2)|(spanSettings[11]+1));
    setRegister(SPAN_A1_REG,((spanSettings[12]+1)<<6)|((spanSettings[13]+1)<<4)|((spanSettings[14]+1)<<2)|(spanSettings[15]+1));
}

void AD7616::setSpan(uint8_t channel, uint8_t span) {
    if (channel == 16){                                                         //Set all spans to the same value
        for (int i=0; i<16; i++) 
            spanSettings[i] = span;                                             //Set internal span variables   
        setRegister(SPAN_A1_REG,((spanSettings[12]+1)<<6)|((spanSettings[13]+1)<<4)|((spanSettings[14]+1)<<2)|(spanSettings[15]+1));
        setRegister(SPAN_A2_REG,((spanSettings[8]+1)<<6)|((spanSettings[9]+1)<<4)|((spanSettings[10]+1)<<2)|(spanSettings[11]+1));
        setRegister(SPAN_B1_REG,((spanSettings[3]+1)<<6)|((spanSettings[2]+1)<<4)|((spanSettings[1]+1)<<2)|(spanSettings[0]+1));
        setRegister(SPAN_B2_REG,((spanSettings[7]+1)<<6)|((spanSettings[6]+1)<<4)|((spanSettings[5]+1)<<2)|(spanSettings[4]+1));
    }
    else if (channel <= 15){                                                    //Set span for single channel
        spanSettings[channel] = span;                                           //Set internal span variable
        if (channel <= 4)                       setRegister(SPAN_B1_REG,((spanSettings[3]+1)<<6)|((spanSettings[2]+1)<<4)|((spanSettings[1]+1)<<2)|(spanSettings[0]+1));
        else if (channel >4 && channel <= 7)    setRegister(SPAN_B2_REG,((spanSettings[7]+1)<<6)|((spanSettings[6]+1)<<4)|((spanSettings[5]+1)<<2)|(spanSettings[4]+1));
        else if (channel >7 && channel <= 11)   setRegister(SPAN_A2_REG,((spanSettings[8]+1)<<6)|((spanSettings[9]+1)<<4)|((spanSettings[10]+1)<<2)|(spanSettings[11]+1));
        else if (channel >11 && channel <= 15)  setRegister(SPAN_A1_REG,((spanSettings[12]+1)<<6)|((spanSettings[13]+1)<<4)|((spanSettings[14]+1)<<2)|(spanSettings[15]+1));
    }
}

void AD7616::setSpanAll(uint8_t spanArray[16]){
    for (int i=0; i<16; i++) spanSettings[i] = spanArray[i];                    //Set internal span variables
    updateSpanAll();                                                            //Update the span register                  
}

uint8_t AD7616::getSpan(uint8_t channel) {                                      
    if (channel <= 15)
        return spanSettings[channel];    
    else return 255;
}

void AD7616::getSpanAll(uint8_t *spanArray){                                    
    for (int i=0; i<16; i++) spanArray[i] = spanSettings[i];
}

////////////////////////////////////////////////////////////////////////////////
//Calibration functions
////////////////////////////////////////////////////////////////////////////////
void AD7616::setCalibration(uint8_t channel, float A, float B) {
    if (channel == 16) {                //Set all calibration values
        for (int i=0; i<16; i++) {
            calSettings[i][0] = A;      //Set calA
            calSettings[i][1] = B;      //Set calB
        }
    }
    else if (channel <= 15) {            //Set calibration values for single channel
        calSettings[channel][0] = A;
        calSettings[channel][1] = B;
    }
}

void AD7616::setCalAll(float data1[16], float data2[16]){
    for (int i=0; i<16; i++){
        calSettings[i][0] = data1[i];
        calSettings[i][1] = data2[i];
    }    
}

void AD7616::getCalibration(uint8_t channel, float& A, float& B) {
    if (channel <= 15) {
        A = calSettings[channel][0];        //Return calibration values
        B = calSettings[channel][1];
    }
}

void AD7616::getCalAll(float *data1, float *data2){
    for (int i=0; i<16; i++){
        data1[i] = calSettings[i][0];
        data2[i] = calSettings[i][1];
    }  
}

////////////////////////////////////////////////////////////////////////////////
//Oversampling
////////////////////////////////////////////////////////////////////////////////
void AD7616::setOversampling(uint8_t setting){
    if (oversampling < 8)
        oversampling = setting;
    setRegister(CONFIGURATION_REG,sdef<<7 | bursten<<6 | seqen<<5 | setting<<2 | statusen<<1 | crcen);
}

uint8_t AD7616::getOversampling(){
    return oversampling;
}

////////////////////////////////////////////////////////////////////////////////
//Interrupt functions
////////////////////////////////////////////////////////////////////////////////
void AD7616::setInterrupt(uint8_t channel, uint8_t mode, float value, float range){
    interruptMode[channel] = mode;
    interruptValue[channel][0] = value;
    interruptValue[channel][1] = range;
    if (mode > 0) interruptEnable = 1;
    else {
        for (int i=0; i<16; i++) {
            if (interruptMode[channel] > 0) {
                interruptEnable = 1;
                break;
            }
        }
    }
}

bool AD7616::checkInterruptEnable() {
    return interruptEnable;
}

uint8_t AD7616::getInterrupt(uint8_t channel, float& value, float& range){
    value = interruptValue[channel][0];
    range = interruptValue[channel][1];
    return interruptMode[channel];
}

bool AD7616::checkInterrupt(uint8_t channel, float& value) {
    if (interruptEnable == 0 && interruptState[channel] == 0) return 0;
    uint8_t mode = interruptMode[channel];
    value = getMeasurement(channel);
    float setpoint = interruptValue[channel][0];
    float range =  interruptValue[channel][1];

    switch (mode) {
        case 0:
            interruptState[channel] = 0;
            return 0;
        case 1:
            if (value < setpoint && interruptState[channel] == 0) {
                interruptState[channel] = 1;
                return 1;  
            } 
            else if  (value >= setpoint) {
                interruptState[channel] = 0;
                return 0;
            }
            else return 0;
        case 2:
            if (value > setpoint && interruptState[channel] == 0){
                interruptState[channel] = 1;
                return 1;   
            }
            else if (value <= setpoint) {
                interruptState[channel] = 0;
                return 0;
            }
            else return 0;
        case 3:
            if (value > (setpoint-range) && value < (setpoint+range) && interruptState[channel] == 0) {
                interruptState[channel] = 1;
                return 1;   
            }
            else if (value < (setpoint-range) || value > (setpoint+range)){
                interruptState[channel] = 0;
                return 0;
            }
            else return 0;
        case 4:
            if ((value < (setpoint-range) || value > (setpoint+range)) && interruptState[channel] == 0) {
                interruptState[channel] = 1;
                return 1;   
            }
            else if (value > (setpoint-range) && value < (setpoint+range)){
                interruptState[channel] = 0;
                return 0;
            }
            else return 0;
    }
    return 0;
}

void AD7616::setIntModeAll(uint8_t data[16]){
    for (int i=0; i<16; i++) interruptMode[i] = data[i];
}

void AD7616::getIntModeAll(uint8_t *data){
    for (int i=0; i<16; i++) data[i] = interruptMode[i];
}

void AD7616::setIntSetpointAll(float data1[16], float data2[16]){
    for (int i=0; i<16; i++){
        interruptValue[i][0] = data1[i];
        interruptValue[i][1] = data2[i];
    }    
}

void AD7616::getIntSetpointAll(float *data1, float *data2){
    for (int i=0; i<16; i++){
        data1[i] = interruptValue[i][0];
        data2[i] = interruptValue[i][1];
    }  
}

void AD7616::setSumEn(uint8_t ch, bool en){
    if (en) sumEn |= 1<<ch;
    else sumEn = ~(~sumEn | (1<<ch));
}

bool AD7616::getSumEn(uint8_t ch){
    return (sumEn>>ch)&1;
}

void AD7616::setSumEnAll(uint16_t data){
    sumEn = data;
}

uint16_t AD7616::getSumEnAll(){
    return sumEn;
}
    
void AD7616::setSumCh(uint8_t chTarget, uint8_t chSource){
    sumSource[chTarget]=chSource;
}

uint8_t AD7616::getSumCh(uint8_t chTarget){
    return sumSource[chTarget];
}

void AD7616::setSumChAll(uint8_t data[16]){
    for (int i=0; i<16; i++) sumSource[i] = data[i];
}

void AD7616::getSumChAll(uint8_t *data){
    for (int i=0; i<16; i++) data[i] = sumSource[i];
}

void AD7616::setSumFactor(uint8_t ch, float factor){
    sumFactor[ch] = factor;
}

float AD7616::getSumFactor(uint8_t ch){
    return sumFactor[ch];
}

void AD7616::setSumFactorAll(float factor[16]){
    for (int i=0; i<16; i++) sumFactor[i] = factor[i];
}
    
void AD7616::getSumFactorAll(float *factor){
    for (int i=0; i<16; i++) factor[i] = sumFactor[i];
}
////////////////////////////////////////////////////////////////////////////////
//Helper functions
////////////////////////////////////////////////////////////////////////////////
void AD7616::channelCorrector(uint8_t channel, uint8_t& correctChannel, bool& selectedADC){
    switch(channel) {
        case 0: correctChannel = CH0; selectedADC = 1; break;
        case 1: correctChannel = CH1; selectedADC = 1; break;
        case 2: correctChannel = CH2; selectedADC = 1; break;
        case 3: correctChannel = CH3; selectedADC = 1; break;
        case 4: correctChannel = CH4; selectedADC = 1; break;
        case 5: correctChannel = CH5; selectedADC = 1; break;
        case 6: correctChannel = CH6; selectedADC = 1; break;
        case 7: correctChannel = CH7; selectedADC = 1; break;
        case 8: correctChannel = CH8; selectedADC = 0; break;
        case 9: correctChannel = CH9; selectedADC = 0; break;
        case 10: correctChannel = CH10; selectedADC = 0; break;
        case 11: correctChannel = CH11; selectedADC = 0; break;
        case 12: correctChannel = CH12; selectedADC = 0; break;
        case 13: correctChannel = CH13; selectedADC = 0; break;
        case 14: correctChannel = CH14; selectedADC = 0; break;
        case 15: correctChannel = CH15; selectedADC = 0; break;
    } 
}

float AD7616::IntToFloat(uint8_t span, int16_t input) {
     float output = 0;
     if (span <= 2) {
         switch(span) {
             case 0:                                                 //+-2.5V
                 output = (float)(input)/11184.64;//should be 13107  11846.4
                 break;
             case 1:                                                //+-5V
                 output = (float)(input)/5592.32;//should be 6553.5 5592.32
                 break;
             case 2:                                                //+-10V
                 output = (float)(input)/2796.16;//should be 3276.75    2796.16
                 break;
        }   
    }
    return (float)output;
}

////////////////////////////////////////////////////////////////////////////////
//Registry
////////////////////////////////////////////////////////////////////////////////
int16_t AD7616::readMeasurement(bool selectedADC) {
    spiADC.frequency(24000000);   
    int16_t output, output1, output2;
    spiADC.format(16,2);
    csADC = 0;
    output1 = spiADC.write(0);
    output2 = spiADC.write(0);
    csADC = 1;
    
    if (selectedADC) output = output2;
    else output = output1;

    return output; 
}

void AD7616::setRegister(uint8_t cmd, uint8_t data) {
    spiADC.frequency(24000000);    
    spiADC.format(16,2);
    csADC = 0;
    spiADC.write((1<<15)|(cmd<<9)|data);
    csADC = 1;
}

int16_t AD7616::readRegister(uint8_t cmd, bool selectedADC) {
    spiADC.frequency(24000000);    
    int16_t output, output1, output2;
    spiADC.format(16,2);
    csADC = 0;
    output1 = spiADC.write((0<<15)|(cmd<<9));
    output2 = spiADC.write((0<<15)|(cmd<<9));
    csADC = 1;
    
    if (selectedADC) output = output2;
    else output = output1;

    return output; 
}