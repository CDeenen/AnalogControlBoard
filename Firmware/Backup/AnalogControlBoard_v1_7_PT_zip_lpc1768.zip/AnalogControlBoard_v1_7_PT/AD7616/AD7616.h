/*
 *   @file       AD7616.cpp
 *   @brief      Header file for AD7616 ADC
 *   @author     Cristian Deenen - Mesoscale Chemical Systems - University of Twente
 *   @device     Analog Control Board - Rev. 1.0
 *   @date       04-10-2018
 *
 * Library for the Analog Devices AD7616, 16-channel DAS with 16-bit, bipolar input, dual simultaneous sampling ADC.
 * Configured for use on the Analog Control Board Rev. 1.0
 */

#ifndef AD7616_H
#define AD7616_H

#include "mbed.h"


/** AD7616 class.
 * Library for the Analog Devices AD7616, 16-channel DAS with 16-bit, bipolar input, dual simultaneous sampling ADC.
 * Configured for use on the Analog Control Board Rev. 1.0
 *
 * @author Cristian Deenen - Mesoscale Chemical Systems - University of Twente
 *
 * <b>AD7616</b> is a class used control the AD7616 ADC for the Analog Control Board
 */       
class AD7616
{
public:

    /** Constructor
     *
     * @brief Constructor
     */
    AD7616(); 
    
    void initialize();
    
    /**
     * @brief Returns the measured value on the set channel after calibration
     * @param channel - selects a channels:
     *      0-15
     * @return Returns measured value as a float after calibration is applied
     */
    float getMeasurement(uint8_t channel);
    
    /**
     * @brief Updates the span register for all channels
     * @return None
    */
    void updateSpanAll();
    /**
     * @brief Sets the input span.
     * @param channel - Sets one or all channels:
     *      0-15 = Single channel
     *      16 = All channels
     * @param span - Span setting 
     *      0 = +-2.5V
     *      1 = +-5V
     *      2 = +-10V
     * @return None
    */
    void setSpan(uint8_t channel, uint8_t span);
    
    /**
     * @brief Sets the input span for all channels.
     * @param spanArray - array of all input spans
     *                  Array length: 16 (uint8_t)
     * @return None
    */
    void setSpanAll(uint8_t spanArray[16]);
    
    /**
     * @brief Returns the set input span.
     * @param channel - Selects channel:
     *      0-15 = Selected channel
     * @return - Span setting given as an integer:
     *      0 = +-2.5V
     *      1 = +-5V
     *      2 = +-10V
    */
    uint8_t getSpan(uint8_t channel);
    
    /**
     * @brief Gets the input span for all channels.
     * @param spanArray - returned array of all input spans
     *                  Array length: 16 (uint8_t)
     * @return None
    */
    void getSpanAll(uint8_t *spanArray);
    
    /**
     * @brief Sets the input calibration settings: value = A*[measuredValue] + B
     * @param channel - Sets one or all channels:
     *      0-15 = Single channel
     *      16 = All channels
     * @param A - Calibration setting A 
     * @param B - Calibration setting B 
     * @return None
    */ 
    void setCalibration(uint8_t channel, float A, float B);
    
    /**
     * @brief Sets the input calibration settings for all channels: value = A*[measuredValue] + B
     * @param data1 - Array containing calibration setting A
     * @param data2 - Array containing calibration setting B
     * @return None
    */ 
    void setCalAll(float data1[16], float data2[16]);
    
    /**
     * @brief Returns the input calibration settings: value = A*[measuredValue] + B
     * @param channel - Selects the channel:
     *      0-15 = Single channel
     * @param A - Calibration setting A 
     * @param B - Calibration setting B 
     * @return None
    */ 
    void getCalibration(uint8_t channel, float& A, float& B);
    
    void getCalAll(float *data1, float *data2);
    
    /**
     * @brief Sets the oversampling rate for all channels.
     * @param setting - Oversampling setting 
     *      0 = no oversampling
     *      1 = 2x oversampling
     *      2 = 4x oversampling
     *      3 = 8x oversampling
     *      4 = 16x oversampling
     *      5 = 32x oversampling
     *      6 = 62x oversampling
     *      7 = 128x oversampling
     * @return None
    */
    void setOversampling(uint8_t setting);
    
    /**
     * @brief Returns the oversampling rate for all channels.
     * @return - Oversampling rate given as an integer: 
     *      0 = no oversampling
     *      1 = 2x oversampling
     *      2 = 4x oversampling
     *      3 = 8x oversampling
     *      4 = 16x oversampling
     *      5 = 32x oversampling
     *      6 = 64x oversampling
     *      7 = 128x oversampling
    */
    uint8_t getOversampling();
    
    /**
     * @brief Resets the AD7616
     * @return None
    */
    void reset();

    /**
     * @brief Sets the AD7616 reset line
     * @param setting - Sets the line HIGH (1) or LOW (0)
     * @return None
    */
    void reset(bool setting);
    
    /**
     * @brief Reads the measurement from the AD7616
     * @param selectedADC - selects ADC 0 or 1 on the AD7616
     * @return Measurement value
    */
    int16_t readMeasurement(bool selectedADC);
    
    void setInterrupt(uint8_t channel, uint8_t mode, float value, float range);
    uint8_t getInterrupt(uint8_t channel, float& value, float& range);
    bool checkInterruptEnable();
    bool checkInterrupt(uint8_t channel, float& value);
    
    void setIntModeAll(uint8_t data[16]);
    void getIntModeAll(uint8_t *data);
    void setIntSetpointAll(float data1[16], float data2[16]);
    void getIntSetpointAll(float *data1, float *data2);
    
    void setSumEn(uint8_t ch, bool en);
    bool getSumEn(uint8_t ch);
    void setSumEnAll(uint16_t data);
    uint16_t getSumEnAll();
    void setSumCh(uint8_t chTarget, uint8_t chSource);
    uint8_t getSumCh(uint8_t chTarget);
    void setSumChAll(uint8_t data[16]);
    void getSumChAll(uint8_t *data);
    void setSumFactor(uint8_t ch, float factor);
    float getSumFactor(uint8_t ch);
    void setSumFactorAll(float factor[16]);
    void getSumFactorAll(float *factor);
    
private:
    void setRegister(uint8_t cmd, uint8_t data);
    int16_t readRegister(uint8_t cmd, bool selectedADC);
    float IntToFloat(uint8_t span, int16_t input);
    void channelCorrector(uint8_t channel, uint8_t& correctChannel, bool& selectedADC);
    uint8_t spanCorrector(uint8_t span);
    
    bool sdef;
    bool bursten;
    bool seqen;
    bool statusen;
    bool crcen;
    uint8_t oversampling;                                                       //Oversampling setting
    uint8_t spanSettings[16];                                                   //Input span settings
    float calSettings[16][2];                                                   //Calibration settings
    uint8_t interruptMode[16];                                                  //Stores the interrupt mode
    float interruptValue[16][2];                                                //Stores the interrupt value [0] & range [1]
    bool interruptEnable;                                                       //Stores interrupt enable flag
    bool interruptState[16];                                                    //Stores when an interrupt is triggered
    uint16_t sumEn;                                                             //Stores enable state of summation for each analog input channel
    uint8_t sumSource[8];                                                       //Stores source channel for the analog input sum (0-7 = analog outputs, 8-23 = analog input-8)
    float sumFactor[16];                                                        //Stores the sum factor
};

#endif /* AD7616_H_ */