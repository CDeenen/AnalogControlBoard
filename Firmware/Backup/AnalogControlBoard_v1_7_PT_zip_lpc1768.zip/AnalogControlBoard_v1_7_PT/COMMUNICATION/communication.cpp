/**
 *   @file       communication.cpp
 *   @brief      Source file for COMMUNICATION
 *   @author     Cristian Deenen - Mesoscale Chemical Systems - University of Twente
 *   @device     Analog Control Board - Rev. 1.0
 *   @date       31-01-2020
 *
 *  Library to handle all communication related functions
 */


#include "mbed.h"
#include "communication.h"
#include "main.h"