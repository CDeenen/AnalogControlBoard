/**
 *   @file       communication.h
 *   @brief      Header file for COMMUNICATION
 *   @author     Cristian Deenen - Mesoscale Chemical Systems - University of Twente
 *   @device     Analog Control Board - Rev. 1.0
 *   @date       31-01-2020
 *
 *  Library to handle communication related functions
 */

#ifndef COMMUNICATION_H
#define COMMUNICATION_H

#include "mbed.h"

/**
 * @author Cristian Deenen - Mesoscale Chemical Systems - University of Twente
 *
 * <b>COMMUNICATION</b> is a class used control the UART communication on the LPC1768 for the Analog Control Board
 */  

#endif /* COMMUNICATION_H_ */