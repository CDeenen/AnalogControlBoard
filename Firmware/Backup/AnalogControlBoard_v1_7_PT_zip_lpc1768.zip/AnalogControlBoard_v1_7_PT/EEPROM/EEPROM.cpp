/**
 *   @file       EEPROM.cpp
 *   @brief      Source file for AT25320B EEPROM
 *   @author     Cristian Deenen - Mesoscale Chemical Systems - University of Twente
 *   @device     Analog Control Board - Rev. 1.0
 *   @date       04-10-2018
 *
 * Library for the Atmel AT25320B EEPROM.
 * Communication protocol: SPI, (8,0), 10MHz
 * 32Kb (4096x8)
 */
 
#include "mbed.h"
#include "EEPROM.h"
#include "main.h"

#define MOSI        P1_24
#define MISO        P1_23
#define SCK         P1_20
#define EEPROM_CS   P3_26

#define WREN        6    //Set write enable latch
#define WRDI        4    //Reset write enable latch (write disable)
#define RDSR        5    //Read status register
#define WRSR        1    //Write status register
#define READ        3    //Read data from memory array
#define WRITE       2    //Write data to memory array

#define SPIFREQ     10000000    //10MHz

//EEPROM addresses//////////////////////
//32Kbit = 4096 bytes = 128 pages (32bytes/page)

                                        //size            total bytes   page    byte
#define ADDR_BAUD               0       //1* uint_32t   = 4             0       0-3
#define ADDR_MULTI_EN           32      //1* uint8_t    = 1             1       0
#define ADDR_MULTI_TIMER        33      //1* uint_32t   = 4             1       1-4
#define ADDR_ESTOP_EN           64      //1* bool       = 1             2       0
#define ADDR_LINK_EN            95      //1* bool       = 1             2       31
#define ADDR_LINK_ANALOG_A      96      //8* uint8_t    = 8             3       0-7
#define ADDR_LINK_ANALOG_B      104     //8* uint8_t    = 8             3       8-15
#define ADDR_LINK_DIGITAL_A     128     //32* uint8_t   = 32           4       0-31
#define ADDR_LINK_DIGITAL_B     160     //32* uint8_t   = 32           5       0-31

#define ADDR_DAC_STARTPOT       320     //8* float      = 32            10      0-31
#define ADDR_DAC_CAL_A          352     //8* float      = 32            11      0-31
#define ADDR_DAC_CAL_B          384     //8* float      = 32            12      0-31
#define ADDR_DAC_SPAN           416     //8* uint8_t    = 8             13      0-7
#define ADDR_DAC_ESTOP_MODE     432     //8* bool       = 8             13      16-23
#define ADDR_DAC_ESTOP_SETPOINT 448     //8* float      = 32            14      0-31
#define ADDR_DAC_MULTI_EN       480     //1* uint8_t    = 1             15      0

#define ADDR_ADC_CAL_A          640     //16* float     = 64            20-21   0-31 0-31
#define ADDR_ADC_CAL_B          704     //16* float     = 64            22-23   0-31 0-31
#define ADDR_ADC_SPAN           768     //16* uint8_t   = 16            24      0-15
#define ADDR_ADC_OS             784     //1* uint8_t    = 1             24      16
#define ADDR_ADC_MULTI_EN       785     //1* uint16_t   = 2             24      17-18
#define ADDR_ADC_INT_EN         800     //16* uint8_t   = 16            25      0-15
#define ADDR_ADC_INT_MODE       816     //16* uint8_t   = 16            25      16-31
#define ADDR_ADC_INT_SETPOINT   832     //16* float     = 64            26-27   0-31 0-31
#define ADDR_ADC_INT_RANGE      896     //16* float     = 64            28-29   0-31 0-31
#define ADDR_ADC_ESTOP_MODE     960     //16* uint8_t   = 16            30      0-15
#define ADDR_ADC_ESTOP_SETPOINT 992     //16* float     = 64            31-32   0-31 0-31
#define ADDR_ADC_ESTOP_RANGE    1056    //16* float     = 64            33-34   0-31 0-31
#define ADDR_ADC_SUM_EN         1120    //1* uint16_t   = 2             35      0-1
#define ADDR_ADC_SUM_SOURCE     1122    //16* uint8_t   = 16            35      2-17
#define ADDR_ADC_SUM_FACTOR     1152    //16* float     = 64            36-37   0-31 0-31

#define ADDR_GPIO_PINMODE       1280    //32* uint8_t   = 32            40      0-31
#define ADDR_GPIO_OUTPUT        1312    //32* bool      = 32            41      0-31  
#define ADDR_GPIO_INT_MODE      1344    //32* uint8_t   = 32            42      0-31
#define ADDR_GPIO_ESTOP_IN_EN   1376    //1* uint32_t   = 4             43      0-3
#define ADDR_GPIO_ESTOP_IN_MODE 1380    //1* uint32_t   = 4             43      4-7
#define ADDR_GPIO_ESTOP_OUT_EN  1384    //1* uint32_t   = 4             43      8-11
#define ADDR_GPIO_ESTOP_OUT_SET 1388    //1* uint32_t   = 4             43      12-15
#define ADDR_GPIO_INVERT        1392    //1* uint32_t   = 4             43      16-19
#define ADDR_GPIO_MULTI_EN      1396    //1* uint32_t   = 4             43      20-23  

#define ADDR_GPIO_PWM_FREQ      1440
#define ADDR_GPIO_PWM_DUTY      1445  

#define ADDR_ENV_EN             1600    //2* bool       = 2             50      0-1
#define ADDR_ENV_MULTI          1602    //2* bool       = 2             50      2-3

#define ADDR_PT_EN              1728    //3*1* bool     = 3             54      0-2    
#define ADDR_PT_BAUD            1731    //3* uint32_t   = 12            54      3-14
#define ADDR_PT_LENGTH          1744    //3* uint8_t    = 3             54      16-18
#define ADDR_PT_STOPBITS        1747    //3* uint8_t    = 3             54      19-21
#define ADDR_PT_NEWLINE         1750    //3* char       = 3             54      22-24
#define ADDR_PT_CONTROL         1753    //3* bool       = 3             54      25-27
#define ADDR_PT_PARITY          1756    //3*uint8_t     = 3             54      28-30

#define ADDR_MON_EN             1920    //1* bool       = 1             60      0
#define ADDR_MON_STATE          1921    //1* bool       = 1             60      1
#define ADDR_MON_OUT_PIN        1922    //1* uint8_t    = 1             60      2
#define ADDR_MON_PERIOD         1923    //1* uint8_t    = 1             60      3
#define ADDR_MON_IN_EN          1936    //16* bool      = 16            60      16-31
#define ADDR_MON_LOWER          1952    //16* float     = 64            61-62   0-31 0-31
#define ADDR_MON_UPPER          2016    //16* float     = 64            63-64   0-31 0-31







//////////////////////////////////////////
DigitalOut csEeprom(EEPROM_CS);
SPI spiEeprom(MOSI, MISO, SCK);


typedef union
{
 float number;
 uint8_t bytes[4];
} FLOATUNION_t;

EEPROM::EEPROM() {
    
}

void EEPROM::initialize() {
    csEeprom = 1;
    
}

/////////////GENERIC/////////////////////////////////////////////////////////////
void EEPROM::setBaud(uint32_t data) {
    write(ADDR_BAUD, data, 4);
}

uint32_t EEPROM::getBaud() {
    return read(ADDR_BAUD, 4);
}

void EEPROM::setMultiEn(uint8_t data) {
    write(ADDR_MULTI_EN,data,1);
}

uint8_t EEPROM::getMultiEn() {
    return read(ADDR_MULTI_EN,1);
}

void EEPROM::setMultiTimer(uint32_t data){
    write(ADDR_MULTI_TIMER,data,4);
}

uint32_t EEPROM::getMultiTimer(){
    return read(ADDR_MULTI_TIMER,4);
}

void EEPROM::setEstopEn(bool data){
    write(ADDR_ESTOP_EN,data,1);
}

bool EEPROM::getEstopEn(){
    return read(ADDR_ESTOP_EN,1);
}


void EEPROM::setLinkEn(bool data){
    write(ADDR_LINK_EN,data,1);
}

bool EEPROM::getLinkEn(){
    return read(ADDR_LINK_EN,1);
}

void EEPROM::setLinkAnalog(uint8_t data1[8], uint8_t data2[8]){
    write(ADDR_LINK_ANALOG_A, data1, 8);
    write(ADDR_LINK_ANALOG_B, data2, 8);  
}

void EEPROM::getLinkAnalog(uint8_t *data1,uint8_t *data2) {
    read(ADDR_LINK_ANALOG_A, data1, 8);
    read(ADDR_LINK_ANALOG_B, data2, 8);
}

void EEPROM::setLinkDigital(uint8_t data1[32], uint8_t data2[32]){
    write(ADDR_LINK_DIGITAL_A, data1, 32);
    write(ADDR_LINK_DIGITAL_B, data2, 32);  
}

void EEPROM::getLinkDigital(uint8_t *data1,uint8_t *data2) {
    read(ADDR_LINK_DIGITAL_A, data1, 32);
    read(ADDR_LINK_DIGITAL_B, data2, 32);
}

/////////////////////////////DAC/////////////////////////////////////////////////////

void EEPROM::setDacStartPot(float data[8]){
    write(ADDR_DAC_STARTPOT, data, 8);
}

void EEPROM::getDacStartPot(float *data){
    read(ADDR_DAC_STARTPOT, data, 8);
}

void EEPROM::setDacCal(float data1[8], float data2[8]){
    write(ADDR_DAC_CAL_A, data1, 8);
    write(ADDR_DAC_CAL_B, data2, 8);
}

void EEPROM::getDacCal(float *data1,float *data2) {
    read(ADDR_DAC_CAL_A, data1, 8);
    read(ADDR_DAC_CAL_B, data2, 8);
}

void EEPROM::setDacSpan(uint8_t data[8]){
    write(ADDR_DAC_SPAN, data, 8);
}

void EEPROM::getDacSpan(uint8_t *data){
    read(ADDR_DAC_SPAN, data, 8);
}

void EEPROM::setDacEstopMode(bool data[8]) {
    write(ADDR_DAC_ESTOP_MODE, data, 8);
}

void EEPROM::getDacEstopMode(bool *data){
    read(ADDR_DAC_ESTOP_MODE, data, 8);
}

void EEPROM::setDacEstopSetpoint(float data[8]){
    write(ADDR_DAC_ESTOP_SETPOINT, data, 8);
}

void EEPROM::getDacEstopSetpoint(float *data){
    read(ADDR_DAC_ESTOP_SETPOINT, data, 8);
}

void EEPROM::setDacMultiEn(uint8_t data){
    write(ADDR_DAC_MULTI_EN,data,1);
}

uint8_t EEPROM::getDacMultiEn(){
    return read(ADDR_DAC_MULTI_EN,1);
}

//////////////////////////////ADC//////////////////////////////////////////////

void EEPROM::setAdcCal(float data1[16], float data2[16]){
    write(ADDR_ADC_CAL_A, data1, 16);
    write(ADDR_ADC_CAL_B, data2, 16);
}

void EEPROM::getAdcCal(float *data1,float *data2) {
    read(ADDR_ADC_CAL_A, data1, 16);
    read(ADDR_ADC_CAL_B, data2, 16);
}

void EEPROM::setAdcSpan(uint8_t data[16]){
    write(ADDR_ADC_SPAN, data, 16);
}

void EEPROM::getAdcSpan(uint8_t *data){
    read(ADDR_ADC_SPAN, data, 16);
}

void EEPROM::setAdcOS(uint8_t data){
    write(ADDR_ADC_OS,data,1);
}

uint8_t EEPROM::getAdcOS(){
    return read(ADDR_ADC_OS,1);
}

void EEPROM::setAdcMultiEn(uint16_t data){
    write(ADDR_ADC_MULTI_EN,data,2);
}

uint16_t EEPROM::getAdcMultiEn(){
    return read(ADDR_ADC_MULTI_EN,2);
}

void EEPROM::setAdcIntMode(uint8_t data[16]){
    write(ADDR_ADC_INT_MODE, data, 16);
}

void EEPROM::getAdcIntMode(uint8_t *data){
    read(ADDR_ADC_INT_MODE, data, 16);
}

void EEPROM::setAdcIntSetpoint(float data1[16], float data2[16]){
    write(ADDR_ADC_INT_SETPOINT, data1, 16);
    write(ADDR_ADC_INT_RANGE, data2, 16);
}

void EEPROM::getAdcIntSetpoint(float *data1,float *data2) {
    read(ADDR_ADC_INT_SETPOINT, data1, 16);
    read(ADDR_ADC_INT_RANGE, data2, 16);
}

void EEPROM::setAdcEstopMode(uint8_t data[16]) {
    write(ADDR_ADC_ESTOP_MODE, data, 16);
}

void EEPROM::getAdcEstopMode(uint8_t *data){
    read(ADDR_ADC_ESTOP_MODE, data, 16);
}

void EEPROM::setAdcEstopSetpoint(float data[16][2]){
    float data1[16];
    float data2[16];
    for (int i=0; i<16; i++) {
        data1[i] = data[i][0];
        data2[i] = data[i][1];
    }
    write(ADDR_ADC_ESTOP_SETPOINT, data1,16);
    write(ADDR_ADC_ESTOP_RANGE, data2,16);
}

void EEPROM::getAdcEstopSetpoint(float *data1,float *data2) {
    read(ADDR_ADC_ESTOP_SETPOINT, data1, 16);
    read(ADDR_ADC_ESTOP_RANGE, data2, 16);
}

void EEPROM::setAdcSumEn(uint16_t data){
    write(ADDR_ADC_SUM_EN, data,2);
}

uint16_t EEPROM::getAdcSumEn(){
    return read(ADDR_ADC_SUM_EN,2);
}

void EEPROM::setAdcSumSource(uint8_t data[16]){
    write(ADDR_ADC_SUM_SOURCE, data, 16);
}

void EEPROM::getAdcSumSource(uint8_t *data){
    read(ADDR_ADC_SUM_SOURCE, data, 16);
}

void EEPROM::setAdcSumFactor(float data[16]){
    write(ADDR_ADC_SUM_FACTOR, data, 16);
}

void EEPROM::getAdcSumFactor(float *data){
    read(ADDR_ADC_SUM_FACTOR, data, 16);
}

////////////////////////////GPIO/////////////////////////////////////

//uint32_t EstopInputPinSetting = 0;          //stores what pins to use as Estop inputs
//    uint32_t EstopOutputPinSetting = 0;         //stores what pins to use as Estop outputs
//    uint32_t EstopOutputSetting = 0;            //Set digital output to value

void EEPROM::setGpioPinmode(uint8_t data1[32],uint8_t data2[32]){
    write(ADDR_GPIO_PINMODE, data1, 32);
    write(ADDR_GPIO_INT_MODE, data2, 32);
}

void EEPROM::getGpioPinmode(uint8_t *data1,uint8_t *data2) {
    read(ADDR_GPIO_PINMODE, data1, 32);
    read(ADDR_GPIO_INT_MODE, data2, 32);
}

void EEPROM::setGpioOutput(bool data[32]) {
    write(ADDR_GPIO_OUTPUT, data, 32);
}

void EEPROM::getGpioOutput(bool *data) {
    read(ADDR_GPIO_OUTPUT, data, 32);
}

void EEPROM::setGpioMulti(uint32_t data){
    write(ADDR_GPIO_MULTI_EN, data, 4);
}

uint32_t EEPROM::getGpioMulti(){
    return read(ADDR_GPIO_MULTI_EN,4);
}

void EEPROM::setGpioEstopInEn(uint32_t data){
    write(ADDR_GPIO_ESTOP_IN_EN, data, 4);
}

uint32_t EEPROM::getGpioEstopInEn(){
    return read(ADDR_GPIO_ESTOP_IN_EN,4);
}

void EEPROM::setGpioEstopInMode(uint32_t data){
    write(ADDR_GPIO_ESTOP_IN_MODE, data, 4);
    
}

uint32_t EEPROM::getGpioEstopInMode(){
    return read(ADDR_GPIO_ESTOP_IN_MODE,4);
}

void EEPROM::setGpioEstopOutMode(uint32_t data){
    write(ADDR_GPIO_ESTOP_OUT_EN, data, 4);
}

uint32_t EEPROM::getGpioEstopOutMode(){
    return read(ADDR_GPIO_ESTOP_OUT_EN,4);
}

void EEPROM::setGpioEstopOutSet(uint32_t data){
    write(ADDR_GPIO_ESTOP_OUT_SET, data, 4);
}

uint32_t EEPROM::getGpioEstopOutSet(){
    return read(ADDR_GPIO_ESTOP_OUT_SET,4);
}

void EEPROM::setGpioInvert(uint32_t data){
    write(ADDR_GPIO_INVERT, data, 4);
}

uint32_t EEPROM::getGpioInvert(){
    return read(ADDR_GPIO_INVERT,4);
}

//set Estop range
/////
//multiUpdateSettingTemp
void EEPROM::setEnvEn(bool data[2]) {
    write(ADDR_ENV_EN, data, 2);
}

void EEPROM::setEnvMulti(uint8_t data) {
    write(ADDR_ENV_MULTI,data,1);
}

void EEPROM::getEnvEn(bool *data){
    read(ADDR_ENV_EN, data, 2);
}

uint8_t EEPROM::getEnvMulti(){
    return read(ADDR_ENV_MULTI,1);
}

///////////////////////////////////////////////////////////////


void EEPROM::setMonitorEn(bool data) {
    write(ADDR_MON_EN,data,1);
}

bool EEPROM::getMonitorEn() {
    return read(ADDR_MON_EN,1);
}

void EEPROM::setMonitorState(uint8_t data) {
    write(ADDR_MON_STATE,data,1);
}

uint8_t EEPROM::getMonitorState() {
    return read(ADDR_MON_STATE,1);
}

void EEPROM::setMonitorPeriod(uint8_t data) {
    write(ADDR_MON_PERIOD,data,1);
}

uint8_t EEPROM::getMonitorPeriod() {
    return read(ADDR_MON_PERIOD,1);
}

void EEPROM::setMonitorOutputPin(uint8_t data){
    write(ADDR_MON_OUT_PIN,data,1);
}

uint8_t EEPROM::getMonitorOutputPin(){
    return read(ADDR_MON_OUT_PIN,1);
}

void EEPROM::setMonInEn(bool data[16]) {
    write(ADDR_MON_IN_EN, data, 16);
}

void EEPROM::getMonInEn(bool *data) {
    read(ADDR_MON_IN_EN, data, 16);
}

void EEPROM::setMonLower(float data[16]){
    write(ADDR_MON_LOWER, data, 16);
}

void EEPROM::getMonLower(float *data){
    read(ADDR_MON_LOWER, data, 16);
}

void EEPROM::setMonUpper(float data[16]){
    write(ADDR_MON_UPPER, data, 16);
}

void EEPROM::getMonUpper(float *data){
    read(ADDR_MON_UPPER, data, 16);
}

///////////////////////////////////////////////////////////
//UART Passthrough
///////////////////////////////////////////////////////////
void EEPROM::setPassthrough(uint8_t channel,bool PT_En,unsigned int PT_Baud,uint8_t PT_Length,uint8_t PT_Parity,uint8_t PT_StopBits,char PT_Newline,bool PT_Control){
    //channel--;
    write((ADDR_PT_EN+channel), PT_En, 1);   
    write(ADDR_PT_BAUD+channel*4,PT_Baud,4);
    write(ADDR_PT_LENGTH+channel, PT_Length, 1);
    write(ADDR_PT_PARITY+channel, PT_Parity,1);
    write(ADDR_PT_STOPBITS+channel, PT_StopBits, 1);
    write(ADDR_PT_NEWLINE+channel, PT_Newline,1);
    write(ADDR_PT_CONTROL+channel, PT_Control,1);  
}

void EEPROM::getPassthrough(uint8_t channel,uint32_t *data){
    //channel--;
    data[0] = read(ADDR_PT_EN+channel,1);//enable
    data[1] = read(ADDR_PT_BAUD+channel*4,4);//baud
    data[2] = read(ADDR_PT_LENGTH+channel,1);//length
    data[3] = read(ADDR_PT_PARITY+channel,1);//parity
    data[4] = read(ADDR_PT_STOPBITS+channel,1);//stop bits
    data[5] = read(ADDR_PT_NEWLINE+channel,1);//newline char
    data[6] = read(ADDR_PT_CONTROL+channel,1);//control 
}

///////////////////////////////////////////////////////////////

void EEPROM::sendAddr(uint8_t cmd, uint16_t addr){
    if (cmd == WRITE) writeEn(); 
    spiEeprom.frequency(SPIFREQ);    //24MHz clock
    spiEeprom.format(8,0);
    csEeprom = 0;
    spiEeprom.write(cmd);
    spiEeprom.write(addr>>8);
    spiEeprom.write(addr&255);
}

uint8_t EEPROM::readStatus(){
    spiEeprom.frequency(SPIFREQ);    //24MHz clock
    spiEeprom.format(8,0);
    csEeprom = 0;
    uint8_t value = spiEeprom.write(RDSR);
    csEeprom = 1;
    return value;
}
void EEPROM::writeEn(){
    spiEeprom.frequency(SPIFREQ);    //24MHz clock
    spiEeprom.format(8,0);
    csEeprom = 0;
    spiEeprom.write(WREN);
    csEeprom = 1;
    wait(0.01);
}
FLOATUNION_t myFloat2;

void EEPROM::read(uint16_t addr, float *data, uint8_t length){
    sendAddr(READ,addr);
    for (int i=0; i<length; i++){
        for (int j=0; j<4; j++)  
            myFloat2.bytes[j] = spiEeprom.write(0);
        data[i] = myFloat2.number;
    }
    csEeprom = 1;
}

void EEPROM::read(uint16_t addr, uint32_t *data, uint8_t length) {
    uint32_t value = 0;
    sendAddr(READ,addr);
    for (int i=0; i<length; i++) {
        for (int j=0; j<4; j++) 
            value |= spiEeprom.write(0) << (j*8);
        data[i] = value;
    }
    csEeprom = 1;
}

void EEPROM::read(uint16_t addr, uint16_t *data, uint8_t length) {
    uint16_t value = 0;
    sendAddr(READ,addr);
    for (int i=0; i<length; i++) {
        for (int j=0; j<2; j++) 
            value |= spiEeprom.write(0) << (j*8);
        data[i] = value;
    }
    csEeprom = 1;
}

void EEPROM::read(uint16_t addr, uint8_t *data, uint8_t length) {
    sendAddr(READ,addr);
    for (int i=0; i<length; i++) 
        data[i] = spiEeprom.write(0);
    csEeprom = 1;
}

void EEPROM::read(uint16_t addr, bool *data, uint8_t length) {
    sendAddr(READ,addr);
    for (int i=0; i<length; i++) 
        data[i] = spiEeprom.write(0);
    csEeprom = 1;
}

float EEPROM::readFloat(uint16_t addr) {
    sendAddr(READ,addr);
    for (int i=0; i<4; i++)  
        myFloat2.bytes[i] = spiEeprom.write(0);
    csEeprom = 1;
    return myFloat2.number;
}

uint32_t EEPROM::read(uint16_t addr, uint8_t size) {
    uint32_t value = 0;
    sendAddr(READ,addr);
    for (int i=0; i<size; i++)  
        value |= spiEeprom.write(0) << (i*8);
    csEeprom = 1;
    return value;
}

FLOATUNION_t myFloat;

void EEPROM::write(uint16_t addr, float data[32], uint8_t length) {
    sendAddr(WRITE,addr);
    for (int i=0; i<length; i++) { 
        myFloat.number = data[i];
        if (i==8 || i == 16 || i == 24) {
            addr += 32;
            csEeprom = 1;
            wait(0.01);
            sendAddr(WRITE,addr);
        }
        for (int j=0; j<4; j++)
            spiEeprom.write(myFloat.bytes[j]); 
    }
    csEeprom = 1;
    wait(0.01);
}

void EEPROM::write(uint16_t addr, uint32_t data[32], uint8_t length){
    sendAddr(WRITE,addr);
    for (int j=0; j<length; j++){
        if (j==8 || j == 16 || j == 24) {
            addr += 32;
            csEeprom = 1;
            wait(0.01);
            sendAddr(WRITE,addr);
        }
        for (int i=0; i<4; i++) 
            spiEeprom.write((data[j]>>(8*i))&255);
    }
    csEeprom = 1;
    wait(0.01);
}

void EEPROM::write(uint16_t addr, bool data[32], uint8_t length){
    sendAddr(WRITE,addr);
    for (int i=0; i<length; i++)
        spiEeprom.write(data[i]);
    csEeprom = 1;
    wait(0.01);
}

void EEPROM::write(uint16_t addr, uint16_t data[32], uint8_t length){
    sendAddr(WRITE,addr);
    for (int j=0; j<length; j++) {
        if (j == 16) {
            addr += 32;
            csEeprom = 1;
            wait(0.01);
            sendAddr(WRITE,addr);
        }
        for (int i=0; i<2; i++) 
            spiEeprom.write((data[j]>>(8*i))&255);
    }
    csEeprom = 1;
    wait(0.01);
}
    
void EEPROM::write(uint16_t addr, uint8_t data[32], uint8_t length){
    sendAddr(WRITE,addr);
    for (int i=0; i<length; i++)
        spiEeprom.write(data[i]);
    csEeprom = 1;
    wait(0.01);
}

void EEPROM::write(uint16_t addr, uint32_t data, uint8_t size) {
    sendAddr(WRITE,addr);
    for (int i=0; i<size; i++){
        spiEeprom.write((data>>(8*i))&255);  
    }
    csEeprom = 1;
    addr++;
    wait(0.01);
}
