/**
 *   @file       EEPROM.cpp
 *   @brief      Header file for AT25320B EEPROM
 *   @author     Cristian Deenen - Mesoscale Chemical Systems - University of Twente
 *   @device     Analog Control Board - Rev. 1.0
 *   @date       04-10-2018
 *
 * Library for the Atmel AT25320B EEPROM.
 * Communication protocol: SPI, (8,0), 10MHz
 * 32Kb (4096x8)
 */

#ifndef EEPROM_H
#define EEPROM_H

#include "mbed.h"

/**
 * @author Cristian Deenen - Mesoscale Chemical Systems - University of Twente
 *
 * <b>EEPROM</b> is a class used control the AT25320B EEPROM for the Analog Control Board
 */
class EEPROM
{
public:
    EEPROM();
    
    void initialize();
    
    //generic
    void setBaud(uint32_t data);
    uint32_t getBaud();
    void setMultiEn(uint8_t data);
    uint8_t getMultiEn();
    void setMultiTimer(uint32_t data);
    uint32_t getMultiTimer();
    void setEstopEn(bool data);
    bool getEstopEn();
    void setLinkEn(bool data);
    bool getLinkEn();
    void setLinkAnalog(uint8_t data1[8], uint8_t data2[8]);
    void getLinkAnalog(uint8_t *data1,uint8_t *data2);
    void setLinkDigital(uint8_t data1[32], uint8_t data2[32]);
    void getLinkDigital(uint8_t *data1,uint8_t *data2);
    //Multi temp/hum
    
    //DAC
    void setDacStartPot(float data[8]);
    void getDacStartPot(float *data);
    void setDacCal(float data1[8], float data2[8]);
    void getDacCal(float *data1,float *data2);
    void setDacSpan(uint8_t data[8]);
    void getDacSpan(uint8_t *data);
    void setDacEstopMode(bool data[8]);
    void getDacEstopMode(bool *data);
    void setDacEstopSetpoint(float data[8]);
    void getDacEstopSetpoint(float *data);
    void setDacMultiEn(uint8_t data);
    uint8_t getDacMultiEn();
    
    //ADC
    void setAdcCal(float data1[16], float data2[16]);
    void getAdcCal(float *data1,float *data2);
    void setAdcSpan(uint8_t data[16]);
    void getAdcSpan(uint8_t *data);
    void setAdcOS(uint8_t data);
    uint8_t getAdcOS();
    void setAdcMultiEn(uint16_t data);
    uint16_t getAdcMultiEn();
    void setAdcIntMode(uint8_t data[16]);
    void getAdcIntMode(uint8_t *data);
    void setAdcIntSetpoint(float data1[16], float data2[16]);
    void getAdcIntSetpoint(float *data1,float *data2);
    void setAdcEstopMode(uint8_t data[16]);
    void getAdcEstopMode(uint8_t *data);
    void setAdcEstopSetpoint(float data[16][2]);
    void getAdcEstopSetpoint(float *data1,float *data2);
    void setAdcSumEn(uint16_t data);
    uint16_t getAdcSumEn();
    void setAdcSumSource(uint8_t data[16]);
    void getAdcSumSource(uint8_t *data);
    void setAdcSumFactor(float data[16]);
    void getAdcSumFactor(float *data);

    //GPIO
    void setGpioPinmode(uint8_t data1[32],uint8_t data2[32]);
    void getGpioPinmode(uint8_t *data1,uint8_t *data2);
    void setGpioOutput(bool data[32]);
    void getGpioOutput(bool *data);
    void setGpioMulti(uint32_t data);
    uint32_t getGpioMulti();
    void setGpioEstopInEn(uint32_t data);
    uint32_t getGpioEstopInEn();
    void setGpioEstopInMode(uint32_t data);
    uint32_t getGpioEstopInMode();
    void setGpioEstopOutMode(uint32_t data);
    uint32_t getGpioEstopOutMode();
    void setGpioEstopOutSet(uint32_t data);
    uint32_t getGpioEstopOutSet();
    void setGpioInvert(uint32_t data);
    uint32_t getGpioInvert();
    //PWM frequency
    //PWM duty
    
    void setEnvEn(bool data[2]);
    void setEnvMulti(uint8_t data);
    void getEnvEn(bool *data);
    uint8_t getEnvMulti();
    
    //Monitor
    void setMonitorEn(bool data);
    bool getMonitorEn();
    void setMonitorState(uint8_t data);
    uint8_t getMonitorState();
    void setMonitorOutputPin(uint8_t data);
    uint8_t getMonitorOutputPin();
    void setMonitorPeriod(uint8_t data);
    uint8_t getMonitorPeriod();
    void setMonInEn(bool data[16]);
    void getMonInEn(bool *data);
    void setMonLower(float data[16]);
    void getMonLower(float *data);
    void setMonUpper(float data[16]);
    void getMonUpper(float *data);

    void setPassthrough(uint8_t channel,bool PT_En,unsigned int PT_Baud,uint8_t PT_Length,uint8_t PT_Parity,uint8_t PT_StopBits,char PT_Newline,bool PT_Control);
    void getPassthrough(uint8_t channel,uint32_t *data);

    void read(uint16_t addr, uint8_t *data, uint8_t length);
    
private:
    uint8_t readStatus();
    void writeEn();
    float readFloat(uint16_t addr);
    void write(uint16_t addr, uint32_t data, uint8_t size);
    void sendAddr(uint8_t cmd, uint16_t addr);
    void write(uint16_t addr, bool data[32], uint8_t = 1);
    void write(uint16_t addr, uint16_t data[32], uint8_t = 1);
    void write(uint16_t addr, uint32_t data[16], uint8_t  = 1);
    void write(uint16_t addr, uint8_t data[32], uint8_t =1);
    void write(uint16_t addr, float data[32], uint8_t length);
    
    uint32_t read(uint16_t addr, uint8_t size);
    void read(uint16_t addr, float *data, uint8_t length);
    void read(uint16_t addr, uint32_t *data, uint8_t length);
    void read(uint16_t addr, uint16_t *data, uint8_t length);
    //void read(uint16_t addr, uint8_t *data, uint8_t length);
    void read(uint16_t addr, bool *data, uint8_t length);
};


#endif /* EEPROM_H_ */