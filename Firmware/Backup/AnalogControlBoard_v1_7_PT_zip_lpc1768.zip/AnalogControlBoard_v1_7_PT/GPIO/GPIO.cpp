/**
 *   @file       GPIO.cpp
 *   @brief      Source file for GPIO
 *   @author     Cristian Deenen - Mesoscale Chemical Systems - University of Twente
 *   @device     Analog Control Board - Rev. 1.0
 *   @date       04-10-2018
 *
 *  Library to handle all GPIO related functions
 */


#include "mbed.h"
#include "GPIO.h"
#include "main.h"


#define SBIT_CNTEN  0           //Counter enable
#define SBIT_PWMEN  2           //PWM enable
#define SBIT_PWMMR0R 1          //PWM match register

#define SBIT_LEN1      1
#define SBIT_LEN2      2
#define SBIT_LEN3      3
#define SBIT_LEN4       4
#define SBIT_LEN5       5
#define SBIT_LEN6       6
#define SBIT_PWMENA1   9
#define SBIT_PWMENA2   10
#define SBIT_PWMENA3   11
#define SBIT_PWMENA4 12
#define SBIT_PWMENA5 13
#define SBIT_PWMENA6 14
#define PWMPRESCALE 0          //23 = 1us


uint8_t pins[32][2] = {{0,29}, //D0
                    {0,30}, //D1
                    {2,2},  //D2
                    {2,3},  //D3
                    {2,4},  //D4
                    {2,5},  //D5
                    {2,8},  //D6
                    {2,9},  //D7
                    {0,16},  //D8 
                    {0,15},  //D9 
                    {0,17},  //D10 
                    {0,18},  //D11 
                    {2,11},  //D12 
                    {2,12},  //D13
                    {0,0},  //D14
                    {0,1},  //D15
                    {0,28},  //D16
                    {0,27},  //D17
                    {0,6},  //D18
                    {0,7},  //D19
                    {0,8},  //D20
                    {0,9},  //D21
                    {1,15},  //D22
                    {1,14},  //D23
                    {1,17},  //D24
                    {1,16},  //D25
                    {2,0},  //D26
                    {2,1},  //D27
                    {1,0},  //D28
                    {1,1},  //D29
                    {1,9},  //D30
                    {1,10}  //D31
                    };
uint32_t reservedPins = 0;
uint32_t PWMperiod = 1000000;
uint32_t PWMwidth[6];

GPIO::GPIO() {
    for (int i=0; i<32; i++) {
        pinmode[i][0] = 2;                 //Set all GPIO to inpt + pulldown
        outputStorage[i] = 0;
    }
    interruptEnable = 0;
    LPC_PWM1->PR = PWMPRESCALE; //1 micro-second resolution
}

//AD7616::~AD7616() {
//}

void GPIO::initialize(){
    for (int i=0; i<32; i++) {
        uint8_t pinMode = pinmode[i][0];
        if (pinMode < 5){                      //if pin is not disabled
            setPinMode(i, pinMode);
            if (pinMode == 3) setOutput(i, outputStorage[i]);
        }
    }
    setPWMperiod(PWMperiod);
}

uint8_t GPIO::getInput(uint8_t pin) {
    if (pinmode[pin][0] > 2) return 2;
    uint8_t value = 3;

    uint8_t port = pins[pin][0];
    uint8_t pinLocation = pins[pin][1];
        
    if (port == 0) value = (LPC_GPIO0->FIOPIN >> pinLocation)&1;
    else if (port == 1) value = (LPC_GPIO1->FIOPIN >> pinLocation)&1;
    else if (port == 2) value = (LPC_GPIO2->FIOPIN >> pinLocation)&1;
    if (getInvert(pin)) value = !value;
    return value;
}

bool GPIO::setOutput(uint8_t pin, bool value) {
    if (pinmode[pin][0] != 3) return 1;
    if (getInvert(pin)) value = !value;
    outputStorage[pin] = value;
    uint8_t port = pins[pin][0];
    uint8_t pinLocation = pins[pin][1];
    uint32_t val = 1<<pinLocation;
    
    if (port == 0) { 
        if (value)  LPC_GPIO0->FIOSET |= val;
        else        LPC_GPIO0->FIOCLR |= val;
    }
    if (port == 1) { 
        if (value)  LPC_GPIO1->FIOSET |= val;
        else        LPC_GPIO1->FIOCLR |= val;
    }
    if (port == 2) { 
        if (value)  LPC_GPIO2->FIOSET |= val;
        else        LPC_GPIO2->FIOCLR |= val;
    }
    return 0;
}

uint8_t GPIO::getOutput(uint8_t pin) {
    if (pinmode[pin][0] != 3) return 2;
    return outputStorage[pin];     
}

uint8_t GPIO::getPinMode(uint8_t pin){
    return pinmode[pin][0];
}

/*
void GPIO::setPinModeRegister(uint8_t pin, uint8_t function) {
    //pins[32][2]
    uint8_t pinSelReg = 0;
    if (pins[pin][0] == 0) pinSelReg = 0;
    else if (pins[pin][0] == 1) pinSelReg = 2;
    else if (pins[pin][0] == 2) pinSelReg = 4;
    
    uint8_t pinBit = pins[pin][1];
    
    if (pinBit > 15) {
        pinSelReg++;
        pinBit -= 16;
    }
    
    if (pinSelReg == 0){
        LPC_PINCON->PINSEL0 = ~(~LPC_PINCON->PINSEL0|(3<<(2*pinBit)));    //Clear
        LPC_PINCON->PINMODE0 |= function<<(2*pinBit);                     //Set
    }
    else if (pinSelReg == 1){
        LPC_PINCON->PINSEL1 = ~(~LPC_PINCON->PINSEL1|(3<<(2*pinBit)));    //Clear
        LPC_PINCON->PINMODE1 |= function<<(2*pinBit);                     //Set
    }
    else if (pinSelReg == 2){
        LPC_PINCON->PINSEL2 = ~(~LPC_PINCON->PINSEL2|(3<<(2*pinBit)));    //Clear
        LPC_PINCON->PINMODE2 |= function<<(2*pinBit);                     //Set
    }
    else if (pinSelReg == 3){
        LPC_PINCON->PINSEL3 = ~(~LPC_PINCON->PINSEL3|(3<<(2*pinBit)));    //Clear
        LPC_PINCON->PINMODE3 |= function<<(2*pinBit);                     //Set
    }
    else if (pinSelReg == 4){
        LPC_PINCON->PINSEL4 = ~(~LPC_PINCON->PINSEL4|(3<<(2*pinBit)));    //Clear
        LPC_PINCON->PINMODE4 |= function<<(2*pinBit);                     //Set
    }
}
*/
uint8_t GPIO::setPinMode(uint8_t pin, uint8_t value) {
    /*
        0 = input no pullup
        1 = input with pullup
        2 = input with pulldown
        3 = output
        4 = PWM
        5 = I2C bus
        6 = SPI bus
        7 = UART bus
    */
    if (getReservedPin(pin)) return 1;
    
    if (value == 4 && (pin < 2 || (pin > 5 && pin != 26 && pin != 27))) return 1;   //requested pinmode is PWM but pin is not PWM capable, return 1
    if (value == 5 && (pin < 14 || pin > 17)) return 1;   //requested pinmode is I2C but pin is not I2C capable, return 1
    if (value == 6 && (pin < 8 || (pin > 11 && pin < 18) || (pin > 21))) return 1;   //requested pinmode is SPI but pin is not SPI capable, return 1
    if (value == 7 && ((pin < 6) || (pin > 9 && pin < 14) || (pin > 15 && pin <26) || pin > 27)) return 1;   //requested pinmode is UART but pin is not UART capable, return 1

    pinmode[pin][0] = value;                                                    //store pinmode in memory
    if (value > 3 && pinmode[pin][1] > 0){                                      //if pinmode is not input and interrupt mode is on
        pinmode[pin][1] = 0;                                                    //turn off interrupt
        interruptEnable = 0;                                                    
        for (int i=0; i<32; i++) {
            if (pinmode[i][1] > 0) {
                interruptEnable = 1;
                break;
            }
        }
    }
    uint8_t port = pins[pin][0];
    uint8_t pinLocation = pins[pin][1];
        
    if (value < 5) {                                                            //if pinmode is simple GPIO or PWM
        //Set pin to GPIO or PWM
        if (port == 0 && pinLocation <= 15) 
            LPC_PINCON->PINSEL0 = ~(~LPC_PINCON->PINSEL0|(3<<(2*pinLocation)));     //set to GPIO
        else if (port == 0 && pinLocation > 15) 
            LPC_PINCON->PINSEL1 = ~(~LPC_PINCON->PINSEL1|(3<<(2*(pinLocation-16))));//set to GPIO
        else if (port == 1 && pinLocation <= 15)
            LPC_PINCON->PINSEL2 = ~(~LPC_PINCON->PINSEL2|(3<<(2*pinLocation)));     //set to GPIO
        else if (port == 1 && pinLocation > 15) 
            LPC_PINCON->PINSEL3 = ~(~LPC_PINCON->PINSEL3|(3<<(2*(pinLocation-16))));//set to GPIO
        else if (port == 2 && pinLocation <= 15){
            LPC_PINCON->PINSEL4 = ~(~LPC_PINCON->PINSEL4|(3<<(2*pinLocation)));     //set to GPIO
            if (value == 4) LPC_PINCON->PINSEL4 |= 1<<(2*pinLocation);              //set to PWM
        }
        else if (port == 2 && pinLocation > 15) 
            LPC_PINCON->PINSEL5 = ~(~LPC_PINCON->PINSEL5|(3<<(2*(pinLocation-16))));//set to GPIO
            
        //Set pin to input or output
        if (value < 4) {
            if (port == 0) {    
                if (value == 3) LPC_GPIO0->FIODIR |= 1<<pinLocation;                //set to output
                else LPC_GPIO0->FIODIR = ~(~LPC_GPIO0->FIODIR|(1<<pinLocation));    //set to input
            }
            if (port == 1) {    
                if (value == 3) LPC_GPIO1->FIODIR |= 1<<pinLocation;                //set to output
                else LPC_GPIO1->FIODIR = ~(~LPC_GPIO1->FIODIR|(1<<pinLocation));    //set to input
            }
            if (port == 2) {    
                if (value == 3) LPC_GPIO2->FIODIR |= 1<<pinLocation;                //set to output
                else LPC_GPIO2->FIODIR = ~(~LPC_GPIO2->FIODIR|(1<<pinLocation));    //set to input
            }
        }
    
        //Set pullup/pulldown
        uint8_t function = 0;
        if (value == 0) function = 2;
        else if (value == 2) function = 3;
        
        if (value <= 2) {
            if (port == 0 && pinLocation <= 15) {
                LPC_PINCON->PINMODE0 = ~(~LPC_PINCON->PINMODE0|(3<<(2*pinLocation)));     //clear
                if (function > 0) LPC_PINCON->PINMODE0 |= function<<(2*pinLocation);       //set
            }
            else if (port == 0 && pinLocation > 15) {
                LPC_PINCON->PINMODE1 = ~(~LPC_PINCON->PINMODE1|(3<<(2*(pinLocation-16))));//clear
                if (function > 0) LPC_PINCON->PINMODE1 |= function<<(2*(pinLocation-16));  //set
            }
            else if (port == 1 && pinLocation <= 15){
                LPC_PINCON->PINMODE2 = ~(~LPC_PINCON->PINMODE2|(3<<(2*pinLocation)));     //clear
                if (function > 0) LPC_PINCON->PINMODE2 |= function<<(2*pinLocation);       //set
            }
            else if (port == 1 && pinLocation > 15) {
                LPC_PINCON->PINMODE3 = ~(~LPC_PINCON->PINMODE3|(3<<(2*(pinLocation-16))));//clear
                if (function > 0) LPC_PINCON->PINMODE3 |= function<<(2*(pinLocation-16));  //set
            }
            else if (port == 2 && pinLocation <= 15){
                LPC_PINCON->PINMODE4 = ~(~LPC_PINCON->PINMODE4|(3<<(2*pinLocation)));     //clear
                if (function > 0) LPC_PINCON->PINMODE4 |= function<<(2*pinLocation);       //set
            }
            else if (port == 2 && pinLocation > 15) {
                LPC_PINCON->PINMODE5 = ~(~LPC_PINCON->PINMODE5|(3<<(2*(pinLocation-16)))); //clear
                if (function > 0) LPC_PINCON->PINMODE5 |= function<<(2*(pinLocation-16));  //set
            }
        }
    }
    else if (value == 5){                                                       // pinmode = I2C bus
        if (pin == 14 || pin == 15)
            LPC_PINCON->PINSEL0 |= 3<<(2*pinLocation);                          //set to function 4 (I2C)
        else if (pin == 16 || pin == 17){
            LPC_PINCON->PINSEL0 = ~(~LPC_PINCON->PINSEL0|(3<<(2*pinLocation))); //clear
            LPC_PINCON->PINSEL0 |= 1<<(2*pinLocation);                          //set to function 2 (I2C)
        }
    }
    /*
        0 = input no pullup
        1 = input with pullup
        2 = input with pulldown
        3 = output
        4 = PWM
        5 = I2C bus
        6 = SPI bus
        7 = UART bus
    */
    else if (value == 6){                                                       // pinmode = SPI bus

    }
    /*
        D6  P2_8    F2
        D7  P2_9    F2
        D8  P0_16   F1
        D9  P0_15   F1
        D14 P0_0    F2
        D15 P0_1    F2
        D26 P2_0    F2
        D27 P2_1    F2
    */    
    
    else if (value == 7) {                                                      // pinmode = UART bus
        if (pin == 6 || pin == 7) {
            LPC_PINCON->PINSEL4 = ~(~LPC_PINCON->PINSEL4|(3<<(2*pinLocation))); //clear
            LPC_PINCON->PINSEL4 |= 2<<(2*pinLocation);                          //set to function 2 (UART)
        }
        else if (pin == 8) {
            LPC_PINCON->PINSEL1 = ~(~LPC_PINCON->PINSEL1|(3<<(2*(pinLocation-16)))); //clear
            LPC_PINCON->PINSEL1 |= 1<<(2*(pinLocation-16));                          //set to function 1 (UART)
        }
        else if (pin == 9) {
            LPC_PINCON->PINSEL0 = ~(~LPC_PINCON->PINSEL0|(3<<(2*pinLocation))); //clear
            LPC_PINCON->PINSEL0 |= 1<<(2*(pinLocation));                          //set to function 1 (UART)
        }
        else if (pin == 14 || pin == 15) {
            LPC_PINCON->PINSEL0 = ~(~LPC_PINCON->PINSEL0|(3<<(2*pinLocation))); //clear
            LPC_PINCON->PINSEL0 |= 2<<(2*pinLocation);                          //set to function 2 (UART)
        }
        else if (pin == 26 || pin == 27) {
            LPC_PINCON->PINSEL4 = ~(~LPC_PINCON->PINSEL4|(3<<(2*pinLocation))); //clear
            LPC_PINCON->PINSEL4 |= 2<<(2*pinLocation);                          //set to function 2 (UART)
        }
    }
    return 0;
}

uint8_t GPIO::setInterrupt(uint8_t pin, uint8_t mode) {
    if (pinmode[pin][0] > 2) return 1;
    pinmode[pin][1] = mode;
    interruptState[pin] = getInput(pin);
    if (mode > 0)
        interruptEnable = 1;
    else {
        interruptEnable = 0;
        for (int i=0; i<32; i++) {
            if (pinmode[i][1] > 0) {
                interruptEnable = 1;
                break;
            }
        }
    }
    return 0;
}

uint8_t GPIO::getInterrupt(uint8_t pin){
    return pinmode[pin][1];
}

bool GPIO::checkInterruptEnable() {
    return interruptEnable;
}

bool GPIO::checkInterrupt(uint8_t pin, bool& value) {
    if (interruptEnable == 0) return 0;
    uint8_t mode = pinmode[pin][1];
    value = getInput(pin);
    bool intStateOld = interruptState[pin];
    interruptState[pin] = value;
    switch (mode) {
        case 0:
            return 0;
        case 1:
            if (intStateOld != value) return 1;   
            else return 0;
        case 2:
            if (intStateOld < value) return 1;   
            else return 0;
        case 3:
            if (intStateOld > value) return 1;   
            else return 0;
    }
    return 0;
}

void GPIO::setPWMfreq(float frequency){
    setPWMperiod((uint32_t)(1000000000/frequency));
}
void GPIO::setPWMperiod(uint32_t period){
    PWMperiod = period;
    LPC_PWM1->MR0 = period*24/1000;
    LPC_PWM1->LER = 1;
    LPC_PWM1->TCR = (1<<1); //Reset PWM TC & PR
    LPC_PWM1->TCR = (1<<0) | (1<<3); //enable counters and PWM Mode 
}

void GPIO::setPWMwidth(uint8_t pin, uint32_t pulseWidth) {
    LPC_PWM1->MCR = (1<<1); //Reset PWM TC on PWM1MR0 match
    if (pin < 26) pin -= 2;
    else pin -= 22;
    PWMwidth[pin] = pulseWidth;
    pulseWidth *= 24;
    pulseWidth /= 1000;
    if (pin == 0) LPC_PWM1->MR3 = pulseWidth;
    else if (pin == 1) LPC_PWM1->MR4 = pulseWidth;
    else if (pin == 2) LPC_PWM1->MR5 = pulseWidth;
    else if (pin == 3) LPC_PWM1->MR6 = pulseWidth;
    else if (pin == 4) LPC_PWM1->MR1 = pulseWidth;
    else if (pin == 5) LPC_PWM1->MR2 = pulseWidth;
    
    LPC_PWM1->LER = (1<<SBIT_LEN1) | (1<<SBIT_LEN2) | (1<<SBIT_LEN3) | (1<<SBIT_LEN4) | (1<<SBIT_LEN5)| (1<<SBIT_LEN6);  //update values in register
    LPC_PWM1->PCR = (1<<SBIT_PWMENA1) | (1<<SBIT_PWMENA2) | (1<<SBIT_PWMENA3) | (1<<SBIT_PWMENA4) | (1<<SBIT_PWMENA5) | (1<<SBIT_PWMENA5); //enable PWM output
}

void GPIO::setPWMduty(uint8_t pin, float duty){
    setPWMwidth(pin,PWMperiod*(duty/100));
}

void GPIO::setPinmodeAll(uint8_t data1[32],uint8_t data2[32]) {
    for (int i=0; i<32; i++) {
        pinmode[i][0] = data1[i];
        pinmode[i][1] = data2[i];
        if (data2[i] > 0)
            interruptEnable = 1;
    }
}
void GPIO::getPinmodeAll(uint8_t *data1,uint8_t *data2) {
    for (int i=0; i<32; i++) {
        data1[i] = pinmode[i][0];
        data2[i] = pinmode[i][1];
    }
}
void GPIO::setOutputAll(bool data[32]){
    for (int i=0; i<32; i++) outputStorage[i] = data[i];
}
void GPIO::getOutputAll(bool *data){
    for (int i=0; i<32; i++) data[i] = outputStorage[i];
}

void GPIO::setReservedPin(uint8_t pin){
    reservedPins |= (1<<pin);
}

void GPIO::clearReservedPin(uint8_t pin){
    reservedPins = ~(~reservedPins | (1<<pin));
}

bool GPIO::getReservedPin(uint8_t pin){
    return reservedPins & (1<<pin);
}

void GPIO::setInvert(uint8_t pin, bool value){
    if (value) invert |= (1<<pin);
    else invert = ~(~invert | 1<<pin);
}

bool GPIO::getInvert(uint8_t pin){
    return (invert>>pin)&1;
}

void GPIO::setInvertAll(uint32_t value){
    invert = value;
}

uint32_t GPIO::getInvertAll(){
    return invert;    
}