/**
 *   @file       GPIO.h
 *   @brief      Header file for GPIO
 *   @author     Cristian Deenen - Mesoscale Chemical Systems - University of Twente
 *   @device     Analog Control Board - Rev. 1.0
 *   @date       04-10-2018
 *
 *  Library to handle all GPIO related functions
 */

#ifndef GPIO_H
#define GPIO_H

#include "mbed.h"


/**
 * @author Cristian Deenen - Mesoscale Chemical Systems - University of Twente
 *
 * <b>GPIO</b> is a class used control the GPIO on the LPC1768 for the Analog Control Board
 */        
class GPIO
{
public:

    /**
     * @brief Constructor
     */
    GPIO(); 
     
    /**
     * @brief Returns the measured value on the set channel after calibration
     * @param channel - selects a channels:
     *      0-15
     * @return Returns measured value as a float after calibration is applied
     */
    uint8_t setPinMode(uint8_t pin, uint8_t value);
    uint8_t getPinMode(uint8_t pin);
    uint8_t getInput(uint8_t pin);
    bool setOutput(uint8_t pin, bool value);
    uint8_t getOutput(uint8_t pin);
    void initialize();
    uint8_t setInterrupt(uint8_t pin, uint8_t mode);
    uint8_t getInterrupt(uint8_t pin);
    bool checkInterruptEnable();
    bool checkInterrupt(uint8_t pin, bool& value);
    void setPWMduty(uint8_t pin, float duty);
    void setPWMwidth(uint8_t pin, uint32_t pulseWidth);
    void setPWMperiod(uint32_t period);
    void setPWMfreq(float frequency);
    void setInvert(uint8_t pin, bool value);
    bool getInvert(uint8_t pin);
    void setInvertAll(uint32_t value);
    uint32_t getInvertAll();
    
    void setPinmodeAll(uint8_t data1[32],uint8_t data2[32]);
    void getPinmodeAll(uint8_t *data1,uint8_t *data2);
    void setOutputAll(bool data[32]);
    void getOutputAll(bool *data); 
    
    void setReservedPin(uint8_t pin);
    void clearReservedPin(uint8_t pin);
    bool getReservedPin(uint8_t pin);

private:
  bool interruptState[32];
   bool interruptEnable;
   bool outputStorage[32];
   uint8_t pinmode[32][2];              //Stores pinmode [n][0], interrupt trigger mode [n][1]
   uint32_t invert;

};

#endif /* GPIO_H_ */