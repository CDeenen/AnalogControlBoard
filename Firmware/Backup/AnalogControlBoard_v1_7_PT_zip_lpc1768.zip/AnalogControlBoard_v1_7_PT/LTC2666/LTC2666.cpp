/**
 *   @file       LTC2666.cpp
 *   @brief      Source file for LTC2666 ADC
 *   @author     Cristian Deenen - Mesoscale Chemical Systems - University of Twente
 *   @device     Analog Control Board - Rev. 1.0
 *   @date       04-10-2018
 *
 * Library for the Linear Technology LTC2666, 8 channel, 16 bit, bipolar DAC
 */
 
#include "mbed.h"
#include "LTC2666.h"
#include "main.h"
//#include "MODSERIAL.h"

#define REG_WRITE_N                 0
#define REG_WRITE_ALL               8
#define REG_SPAN_N                  6
#define REG_SPAN_ALL                14
#define REG_UPDATE_N                1
#define REG_UPDATE_ALL              9
#define REG_UPDATE_N_WRITE_N        3
#define REG_UPDATE_N_WRITE_ALL      2
#define REG_UPDATE_ALL_WRITE_ALL    10
#define REG_POWERDOWN_N             8
#define REG_POWERDOWN_CHIP          9
#define REG_ANALOGMUX               11
#define REG_TOGGLESELECT            12
#define REG_GLOBALTOGGLE            13
#define REG_CONFIG                  7
#define REG_NO_OPERATION            15

#define CH0 3
#define CH1 2
#define CH2 1
#define CH3 0
#define CH4 7
#define CH5 6
#define CH6 5
#define CH7 4

#define MOSI    P1_24
#define MISO    P1_23
#define SCK     P1_20
#define CS      P1_28
#define TGP     P1_27
#define LDAC    P1_29
#define CLR     P0_10
#define OVRTMP  P0_11

//MODSERIAL pcDAC(USBTX, USBRX);
SPI spi(MOSI, MISO, SCK); // mosi, miso, sclk
DigitalOut cs(CS);      //chip select
DigitalOut tgp(TGP);    //Asynchronous Toggle Pin
DigitalOut clr(CLR);    //Asynchronous Clear Input
DigitalOut ldac(LDAC);  //Asynchronous DAC Update Pin
DigitalIn ovrtmp(OVRTMP);
    
LTC2666::LTC2666() {
    for (int i=0; i<8; i++) {
        calSettings[i][0] = 1;      //Set calA to 1
        calSettings[i][1] = 0;      //Set calB to 0
        spanSettings[i] = 2;                //Set span to +-10V
        potential[i] = 0;
    }
    //pcDAC.baud(115200);
    
    
    
}

//LTC2666::~LTC2666() {
//}

void LTC2666::initialize(){
    ldac = 1;
    tgp = 0;
    cs = 1;
    clr = 1;
    
    for (int i=0; i<8; i++) {
        setSpan(i, spanSettings[i]);
        setCalibration(i, calSettings[i][0], calSettings[i][1]);
        setOutput(i, potential[i]);
    }
}

void LTC2666::setRegister(uint8_t cmd, uint8_t addr, uint16_t data) {
    spi.frequency(24000000);    //24MHz clock
    uint8_t D1 = (cmd<<4)|addr;
    uint8_t D2 = data>>8;
    uint8_t D3 = data&255;
    
    
    spi.format(8,0);
    cs = 0;
    spi.write(D1);
    spi.write(D2);
    spi.write(D3);
    cs = 1;
    
    //pcDAC.printf("REGSET D1: %d, D2: %d, D3: %d\n",D1,D2,D3);
    
    /*
    
    message("REGSET DAC data: ");
    message(data);
    message("\tD1:");
    message(D1);
    message("\tD2:"); 
    message(D2);
    message("\tD3:"); 
    message(D3);
    message("\n"); 
    */
}

uint16_t LTC2666::FloatToInt(uint8_t span, float input) {
     uint32_t output = 0;
     if (span <= 4) {
         switch(span) {
             case 0:                                                 //+-2.5V
                 output = (uint32_t)((input+2.5)*13107);
                 break;
             case 1:                                                //+-5V
                 output = (uint32_t)((input+5)*6553.5);
                 break;
             case 2:                                                //+-10V
                 output = (uint32_t)((input+10)*3276.75);
                 break;
             case 3:                                                //0-5V
                 output = (uint32_t)(input*13107);
                 break;
             case 4:                                                //0-10V
                 output = (uint32_t)(input*6553.5);
                 break;
        }   
        if (output > 65535) output = 65535; 
    }
    return (uint16_t)output;
}

uint8_t LTC2666::spanCorrector(uint8_t span){
    uint8_t output;
    switch(span) {
        case 0: output = 4; break;
        case 1: output = 2; break;
        case 2: output = 3; break;
        case 3: output = 0; break;
        case 4: output = 1; break;
    }
    return output;
}

uint8_t LTC2666::channelCorrector(uint8_t channel) {
    uint8_t output;
    switch(channel) {
        case 0: output = CH0; break;
        case 1: output = CH1; break;
        case 2: output = CH2; break;
        case 3: output = CH3; break;
        case 4: output = CH4; break;
        case 5: output = CH5; break;
        case 6: output = CH6; break;
        case 7: output = CH7; break;
    } 
    return output;
}

void LTC2666::setOutput(uint8_t channel, float value) {
    if (channel == 8) 
        for (int i=0; i<8; i++) 
            setOutput(i,value);
    else if (channel <=7) {
        potential[channel] = value;
        float A, B;
        getCalibration(channel,A,B);
        float output = A*value + B;
        setRegister(REG_UPDATE_N_WRITE_N,channelCorrector(channel),FloatToInt(spanSettings[channel],output));
    }
}

float LTC2666::getOutput(uint8_t channel) {
    return potential[channel];
}

void LTC2666::setSpan(uint8_t channel, uint8_t span) {
    if (channel == 8)                  //Set all span values
        for (int i=0; i<8; i++) {
            spanSettings[i] = span;     //Set span  
            setRegister(REG_SPAN_ALL, 0, spanCorrector(span));
        }  
    else if (channel <= 7) {             //Set span value for single channel
        spanSettings[channel] = span; 
        setRegister(REG_SPAN_N, channelCorrector(channel), spanCorrector(span));
    }
}

uint8_t LTC2666::getSpan(uint8_t channel) {
    if (channel <= 7)
        return spanSettings[channel];       //Return span setting
    else return 255;
}

void LTC2666::setCalibration(uint8_t channel, float A, float B) {
    if (channel == 8) {                //Set all calibration values
        for (int i=0; i<8; i++) {
            calSettings[i][0] = A;      //Set calA
            calSettings[i][1] = B;      //Set calB
        }
    }
    else if (channel <= 7) {            //Set calibration values for single channel
        calSettings[channel][0] = A;
        calSettings[channel][1] = B;
    }
}

void LTC2666::getCalibration(uint8_t channel, float& A, float& B) {
    if (channel <= 7) {
        A = calSettings[channel][0];        //Return calibration values
        B = calSettings[channel][1];
    }
}

void LTC2666::setStartPotAll(float data[8]){
    for (int i=0; i<8; i++) potential[i] = data[i];
}

void LTC2666::getStartPotAll(float *data){
    for (int i=0; i<8; i++) data[i] = potential[i];
}

void LTC2666::setSpanAll(uint8_t data[8]){
    for (int i=0; i<8; i++) spanSettings[i] = data[i];
}

void LTC2666::getSpanAll(uint8_t *data){
    for (int i=0; i<8; i++) data[i] = spanSettings[i];
}

void LTC2666::setCalAll(float data1[8], float data2[8]){
    for (int i=0; i<8; i++){
        calSettings[i][0] = data1[i];
        calSettings[i][1] = data2[i];
    }    
}

void LTC2666::getCalAll(float *data1, float *data2){
    for (int i=0; i<8; i++){
        data1[i] = calSettings[i][0];
        data2[i] = calSettings[i][1];
    }  
}