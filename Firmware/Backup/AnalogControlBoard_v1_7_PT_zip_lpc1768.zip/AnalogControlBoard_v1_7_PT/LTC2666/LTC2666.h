/**
 *   @file       LTC2666.cpp
 *   @brief      Header file for LTC2666 DAC
 *   @author     Cristian Deenen - Mesoscale Chemical Systems - University of Twente
 *   @device     Analog Control Board - Rev. 1.0
 *   @date       04-10-2018
 *
 * Library for the Linear Technology LTC2666, 8 channel, 16 bit, bipolar DAC
 */

#ifndef LTC2666_H
#define LTC2666_H

#include "mbed.h"

/**
 * @author Cristian Deenen - Mesoscale Chemical Systems - University of Twente
 *
 * <b>LTC2666</b> is a class used control the LTC2666 DAC for the Analog Control Board
 */
class LTC2666
{
public:

    /**
     * @brief Constructor
     */
    LTC2666(); 
    
    void initialize();
    
    /**
     * Sets the output value on the set channel after calibration
     * @param channel - Sets one or all channels:
     *      0-7 = Single channel
     *      8 = All channels
     * @param value - Requested value, before calibration
     * @return none
     */
    void setOutput(uint8_t channel, float value);
    
    /**
     * @brief Gets the set output value on the set channel
     * @param channel - Sets one channel:
     *      0-7 = Single channel
     * @return float
     */
    float getOutput(uint8_t channel);
    
    /**
     * @brief Sets the output span.
     * @param channel - Sets one or all channels:
     *      0-7 = Single channel
     *      8 = All channels
     * @param span - Span setting 
     *      0 = +-2.5V
     *      1 = +-5V
     *      2 = +-10V
     *      3 = 0-5V
     *      4 = 0-10V
     * @return None
    */
    void setSpan(uint8_t channel, uint8_t span);
    
    /**
     * @brief Returns the set output span.
     * @param channel - Selects channel:
     *      0-7 = Selected channel
     * @return - Span setting given as an integer:
     *      0 = +-2.5V
     *      1 = +-5V
     *      2 = +-10V
     *      3 = 0-5V
     *      4 = 0-10V
    */
    uint8_t getSpan(uint8_t channel);
    
    /**
     * @brief Sets the output calibration settings: value = A*[setValue] + B
     * @param channel - Sets one or all channels:
     *      0-7 = Single channel
     *      8 = All channels
     * @param A - Calibration setting A 
     * @param B - Calibration setting B 
     * @return None
    */ 
    void setCalibration(uint8_t channel, float A, float B);
    
    /**
     * @brief Returns the output calibration settings: value = A*[setValue] + B
     * @param channel - Selects the channel:
     *      0-7 = Single channel
     * @param A - Calibration setting A 
     * @param B - Calibration setting B 
     * @return None
    */ 
    void getCalibration(uint8_t channel, float& A, float& B);
    
    /**
     * @brief Resets the LTC2666
     * @return None
    */
    void reset();

    /**
     * @brief Sets the LTC2666 reset line
     * @param setting - Sets the line HIGH (1) or LOW (0)
     * @return None
    */
    void reset(bool setting);
    
    /**
     * @brief Sets the starting potential for all channels (for EEPROM)
     * @param data[8] - Array containing all the potentials
     * @return None
    */ 
    void setStartPotAll(float data[8]);
    
    /**
     * @brief Gets the starting potential for all channels (for EEPROM)
     * @param data[8] - Array containing all the potentials
     * @return None
    */ 
    void getStartPotAll(float *data);
    
    /**
     * @brief Sets the span for all channels (for EEPROM)
     * @param data[8] - Array containing all the spans
     * @return None
    */ 
    void setSpanAll(uint8_t data[8]);
    
    /**
     * @brief Gets the span for all channels (for EEPROM)
     * @param data[8] - Array containing all the spans
     * @return None
    */ 
    void getSpanAll(uint8_t *data);
    
    /**
     * @brief Sets the output calibration settings for all channels: value = A*[setValue] + B
     * @param data1[8] - Array containing all the CalA settings
     * @param data2[8] - Array containing all the CalB settings
     * @return None
    */ 
    void setCalAll(float data1[8], float data2[8]);
    
    /**
     * @brief Gets the output calibration settings for all channels: value = A*[setValue] + B
     * @param data1[8] - Array containing all the CalA settings
     * @param data2[8] - Array containing all the CalB settings
     * @return None
    */ 
    void getCalAll(float *data1, float *data2);
    
private:

    /**
     * @brief Sets a register on the LTC
     * @param cmd - Determines what kind of register has to be set
     * @param addr - Sets the address of the register
     * @param data - The data to be sent
     * @return None
    */ 
    void setRegister(uint8_t cmd, uint8_t addr, uint16_t data);
    
    /**
     * @brief Converts floating point potential to the correct unsigned integer value to send to LTC
     * @param span - Output span
     * @param input - Input potential
     * @return 16-bit unsigned integer
    */ 
    uint16_t FloatToInt(uint8_t span, float input);
    
    /**
     * @brief Converts channel numbers used by ACB to channel numbers used by LTC
     * @param channel - Channel number as used by ACB
     * @return Channel number as used by LTC
    */   
    uint8_t channelCorrector(uint8_t channel);
    
    /**
     * @brief Converts span label used by ACB to span label used by LTC
     * @param span - span label as used by ACB
     * @return Span label as used by LTC
    */  
    uint8_t spanCorrector(uint8_t span);
    
    float potential[8];                                                         //stores output potentials
    uint8_t spanSettings[8];                                                    //Output span settings
    float calSettings[8][2];                                                    //Calibration settings

};

#endif /* LTC2666_H_ */