/*

*/
#include "mbed.h"
#include <string>
#include <cstdlib>
#include "MODSERIAL.h"
#include "AD7616.h"
#include "LTC2666.h"
#include "main.h"
#include "GPIO.h"
#include "EEPROM.h"
#include "BME280.h"
#include <LiquidCrystal_I2C.h>

/*------------------------------------------------------------------------------
User Settings
------------------------------------------------------------------------------*/
#define DEBUG   1
    //Set to 1 to get debug info over the USB port

#define ESPINNING   3                                                           
/*
    Set to >1 to enable electrospinning specific features
    1 = Toolchanger system
    2 = Glovebox system
    3 = Bjorn System
*/

#define UART1_CH 0
    //0 sets UART1 to pins D26/D27, 1 sets UART1 to pins D8/D9


/*------------------------------------------------------------------------------
End of User Settings
------------------------------------------------------------------------------*/

#define SERIALBUFFER 256
#define MESSAGE_BUFFER_SIZE 256
#define NAME "Analog Control Board"
#define SWVERSION "V1.7.1"
#define HWVERSION "V1.0"
#define DATE "12-03-2020"

#if ESPINNING == 1
    #define HOMINGPIN           4
    #define NOZZLE_POT_OUT      2
    #define NOZZLE_POT_IN       -1
    #define NOZZLE_CURR_IN      6
    #define NOZZLE_EN_PIN       -1
    #define COLLECTOR_POT_OUT   4 
    #define COLLECTOR_POT_IN    -1
    #define COLLECTOR_CURR_IN   -1
    #define COLLECTOR_EN_PIN    -1
    #define AUX1_POT_OUT        6
    #define AUX1_EN_PIN         -1
    #define AUX2_POT_OUT        0
    #define AUX2_EN_PIN         -1
    #define DOORSWITCH_PIN      -1
    #define HOMING_CURRENT      1       //uA
    #define HOMING_POTENTIAL    0.250   //kV
#elif ESPINNING == 2
    #define HOMINGPIN           24
    #define NOZZLE_POT_OUT      7
    #define NOZZLE_POT_IN       9
    #define NOZZLE_CURR_IN      8
    #define NOZZLE_EN_PIN       13
    #define COLLECTOR_POT_OUT   6 
    #define COLLECTOR_POT_IN    10
    #define COLLECTOR_CURR_IN   11
    #define COLLECTOR_EN_PIN    12  
    #define DOORSWITCH_PIN      23
    #define HOMING_CURRENT      1       //uA
    #define HOMING_POTENTIAL    0.250   //kV
#elif ESPINNING == 3
    #define NOZZLE_POT_OUT      6
    #define NOZZLE_POT_IN       11
    #define NOZZLE_CURR_IN      9
    #define NOZZLE_EN_PIN       8
    #define COLLECTOR_POT_OUT   7 
    #define COLLECTOR_POT_IN    10
    #define COLLECTOR_CURR_IN   8
    #define COLLECTOR_EN_PIN    10  
#endif

#if ESPINNING == 3
    LiquidCrystal_I2C lcd(0x4e, 20, 4);
#endif

int EstopSource = 0;

EEPROM eeprom;
DigitalOut LED(P2_13);
DigitalIn EepromEn(P0_25);
bool LEDstate = 0;
Timer ledTimer;
Timer monitorTimer;
Timer monitorBlinkTimer;

#if UART1_CH
    Serial UART1(P0_15, P0_16);
#else
    Serial UART1(P2_0, P2_1);
#endif
char PT1_Buffer[MESSAGE_BUFFER_SIZE];
uint8_t PT1_BufferCounter = 0;
MODSERIAL UART2(P2_8, P2_9);
char PT2_Buffer[MESSAGE_BUFFER_SIZE];
uint8_t PT2_BufferCounter = 0;
MODSERIAL UART3(P0_0, P0_1);
char PT3_Buffer[MESSAGE_BUFFER_SIZE];
uint8_t PT3_BufferCounter = 0;

bool PT_En[3] = {false,false,false};
unsigned int PT_Baud[3] = {115200,115200,115200};
uint8_t PT_Length[3] = {8,8,8};
uint8_t PT_Parity[3] = {0,0,0};
uint8_t PT_StopBits[3] = {1,1,1};
char PT_Newline[3] = {'\n','\n','\n'};
bool PT_Control[3] = {false,false,false};
#define WATCHDOG_TIME 30

AD7616 adc;
LTC2666 dac;
GPIO gpio;
MODSERIAL pc(USBTX, USBRX, SERIALBUFFER);
bool envEn[2] = {0,0};
BME280 BME280_0(P0_0, P0_1);
#if ESPINNING != 3
    BME280 BME280_1(P0_27, P0_28);
#endif

unsigned int SerialBaud = 115200;
volatile bool newline_detected = false;
char messageBufferIncoming[MESSAGE_BUFFER_SIZE];
char messageBufferOutgoing[MESSAGE_BUFFER_SIZE];

uint8_t analogLink[8];
uint8_t analogLinkEn[8];
uint8_t digitalLink[32];
uint8_t digitalLinkEn[32];
bool linkEn = false;

float analogOutputU[8] = {0,0,0,0,0,0,0,0};
float analogInputU[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

float temperature0 = 0;
float humidity0 = 0;
float pressure0 = 0;
float temperature1 = 0;
float humidity1 = 0;
float pressure1 = 0;

Timer rampTimer;

//Multiupdate settings///////////////////////////////////////
bool multiUpdateEnable[4] = {0,0,0,0};                                                     //Turns multi update on or off
uint16_t multiUpdateSettingAin = 0;                                             //Stores what analog input channels are enabled
uint8_t multiUpdateSettingAout = 0;                                             //Stores what analog output channels are enabled
uint32_t multiUpdateSettingDin = 0;                                             //Stores what digital input channels are enabled
uint8_t multiUpdateSettingTemp = 0; 
uint32_t multiUpdateInterval = 100;                                             //Stores the multi update period (ms)
Timer multiUpdateTimer;

//Estop settings////////////////////////////////////////////
bool EstopEnable = 0;
uint32_t EstopInputPinSetting = 0;                                              //stores what pins to use as Estop inputs
uint32_t EstopOutputPinSetting = 0;                                             //stores what pins to use as Estop outputs

uint32_t EstopInputSetting = 0;
uint8_t EstopInputASettings[16];                                                //stores AIn Estop mode
bool EstopOutputASettings[8];                                                   //stores AOut Estop mode (on or off)
float EstopInputASetting[16][2];                                                //stores AIn Estop setpoint [0] & range [1]
uint32_t EstopOutputSetting = 0;            
float EstopOutputASetting[8];                                                   //stores output potential 
    
bool EstopFlag = 1;        
bool EstopTrigger = 1;
bool EstopTriggered = 0;
#define EstopDelay 1000
Timer EstopTimer;

float homingCurrent = 10;
float homingPotential = 0.05;
bool homingEn = 0;

bool monitorEn = 0;
uint8_t monitorState = 0;
uint8_t monitorOutputPin = 0;
uint8_t monitorBlinkPeriod = 10;
bool monitorInputEn[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
float monitorLower[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
float monitorUpper[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

uint16_t analogInSumEn = 0;     //stores enable state of summation for each analog input channel
uint8_t analogOutSumEn = 0;
uint8_t analogOutSumSource[8]; //stores source channel for the analog output sum (0-7 = analog outputs, 8-23 = analog input-8)
uint8_t analogInSumSource[16];
float analogInSumFactor[16];
float analogOutSumFactor[8];


class Watchdog {                                                                //Watchdog timer class
public:
    void kick(float s) {                                                        //Function to set watchdog trigger time
        LPC_WDT->WDCLKSEL = 0x1;                                                //Set CLK src to PCLK
        uint32_t clk = SystemCoreClock / 16;                                    //WD has a fixed /4 prescaler, PCLK default is /4 
        LPC_WDT->WDTC = s * (float)clk;         
        LPC_WDT->WDMOD = 0x3;                                                   // Enabled and Reset        
        kick();
    }
    
    void kick() {                                                               //Function to kick the dog
        LPC_WDT->WDFEED = 0xAA;
        LPC_WDT->WDFEED = 0x55;
    }
};

Watchdog w;

void messageReceive(MODSERIAL_IRQ_INFO *q) {                                    //Called when a character is received over the serial port
    MODSERIAL *sys = q->serial;
    if ( sys->rxGetLastChar() == '\n')                                          //If newline, set flag
        newline_detected = true;
    sys->move(messageBufferIncoming, MESSAGE_BUFFER_SIZE);                      //Move character to buffer
    return;
}

void messageBIN(uint16_t message) {
    for (int i=0; i<16; i++) {
        pc.printf("%d",(message>>(15-i))&1);
        if (i == 3 || i == 7 || i == 11) pc.printf(" ");
    }
}

void message(string message){
    pc.printf("%s", message.c_str());
}
void message(float message){
    pc.printf("%f", message);
}
void message(int message){
    pc.printf("%d", message);
}
void message(uint32_t message){
    pc.printf("%d", message);
}

void Error(int type){
    if (type == 0) pc.printf("ERROR: Invalid command\n");
    else if (type == 1) pc.printf("ERROR: Invalid channel\n");
    else if (type == 2) pc.printf("ERROR: Invalid pin\n");
    else if (type == 3) pc.printf("ERROR: Invalid span\n");
    else if (type == 4) pc.printf("ERROR: Invalid value\n");
}

void Error(string message){
    pc.printf("ERROR: %s\n", message.c_str());
}

void setBaud(string data) {
    pc.printf("OK\n");  
    SerialBaud = atoi(data.c_str());
    pc.baud(SerialBaud);
}

void getBaud() {
    pc.printf("BAUD %d\n",SerialBaud);
}

uint32_t stringToInteger(string data,uint8_t size, uint8_t offset) {
    uint32_t result = 4294967295;
    for (int i=0; i<size; i++) {
        uint8_t addr = i+offset;
        if (data[addr] >= '0' && data[addr] <= '9') {
            if (i == 0) result = 0;
            else result *= 10;
            result += data[addr] - '0';
        }
        else return result;
    }
    return result;
}


/*           
uint32_t multiUpdateSettingDin = 0;
uint32_t EstopInputPinSetting = 0;          //stores what pins to use as Estop inputs
uint32_t EstopInputChSetting = 0;           //stores what analog inputs to use as Estop inputs
uint32_t EstopOutputPinSetting = 0;         //stores what pins to use as Estop outputs


uint32_t EstopInputSetting = 0;
uint8_t EstopInputASettings[16];             //stores AIn Estop mode
float EstopInputASetting[16][2];            //stores AIn Estop setpoint [0] & range [1]
uint32_t EstopOutputSetting = 0;  
*/
void saveEeprom() {
    w.kick();
    eeprom.setBaud(SerialBaud);
    eeprom.setMultiEn(multiUpdateEnable[0] | multiUpdateEnable[1]<<1 | multiUpdateEnable[2]<<2 | multiUpdateEnable[3]<<3);
    eeprom.setMultiTimer(multiUpdateInterval);
    eeprom.setEstopEn(EstopEnable);
    eeprom.setLinkEn(linkEn);
    eeprom.setLinkAnalog(analogLink,analogLinkEn);
    eeprom.setLinkDigital(digitalLink,digitalLinkEn);
    //Multi temp/hum
    
    //DAC
    float tempF8_1[8];
    float tempF8_2[8];
    uint8_t tempU8[8];
    dac.getStartPotAll(tempF8_1);
    eeprom.setDacStartPot(tempF8_1);
    dac.getSpanAll(tempU8);
    eeprom.setDacSpan(tempU8);
    dac.getCalAll(tempF8_1, tempF8_2);
    eeprom.setDacCal(tempF8_1, tempF8_2);
    eeprom.setDacEstopMode(EstopOutputASettings);
    eeprom.setDacEstopSetpoint(EstopOutputASetting);
    eeprom.setDacMultiEn(multiUpdateSettingAout);
    
    //ADC
    float tempF16_1[16];
    float tempF16_2[16];
    uint8_t tempU16[16];
    adc.getCalAll(tempF16_1, tempF16_2);
    eeprom.setAdcCal(tempF16_1, tempF16_2);
    adc.getSpanAll(tempU16);
    eeprom.setAdcSpan(tempU16);
    eeprom.setAdcOS(adc.getOversampling());
    eeprom.setAdcMultiEn(multiUpdateSettingAin);
    adc.getIntModeAll(tempU16);
    eeprom.setAdcIntMode(tempU16);
    adc.getIntSetpointAll(tempF16_1, tempF16_2);
    eeprom.setAdcIntSetpoint(tempF16_1, tempF16_2);
    eeprom.setAdcEstopMode(EstopInputASettings);
    eeprom.setAdcEstopSetpoint(EstopInputASetting);
    eeprom.setAdcSumEn(adc.getSumEnAll());
    adc.getSumChAll(tempU16);
    eeprom.setAdcSumSource(tempU16);
    adc.getSumFactorAll(tempF16_1);
    eeprom.setAdcSumFactor(tempF16_1);
    w.kick();
    
    //GPIO
    uint8_t tempU32_1[32];
    uint8_t tempU32_2[32];
    bool tempB32[32];
    gpio.getPinmodeAll(tempU32_1,tempU32_2);
    eeprom.setGpioPinmode(tempU32_1,tempU32_2);
    gpio.getOutputAll(tempB32);
    eeprom.setGpioOutput(tempB32);
    eeprom.setGpioMulti(multiUpdateSettingDin);
    eeprom.setGpioEstopInEn(EstopInputPinSetting);
    eeprom.setGpioEstopInMode(EstopInputSetting);
    eeprom.setGpioEstopOutMode(EstopOutputPinSetting);
    eeprom.setGpioEstopOutSet(EstopOutputSetting);
    eeprom.setGpioInvert(gpio.getInvertAll());
    
    //ENV
    eeprom.setEnvEn(envEn);
    eeprom.setEnvMulti(multiUpdateSettingTemp);
    
    //Monitor
    eeprom.setMonitorEn(monitorEn);
    eeprom.setMonitorState(monitorState);
    eeprom.setMonitorPeriod(monitorBlinkPeriod);
    eeprom.setMonitorOutputPin(monitorOutputPin);
    eeprom.setMonInEn(monitorInputEn);
    eeprom.setMonLower(monitorLower);
    eeprom.setMonUpper(monitorUpper);
    
    //UART Passthrough
    for (int i=0; i<3; i++) eeprom.setPassthrough(i,PT_En[i],PT_Baud[i],PT_Length[i],PT_Parity[i],PT_StopBits[i],PT_Newline[i],PT_Control[i]);
}

void loadEeprom() {
    SerialBaud = eeprom.getBaud();
    uint8_t temp = eeprom.getMultiEn();
    for (int i=0; i<4; i++) multiUpdateEnable[i]=(temp>>i)&1;
    multiUpdateInterval = eeprom.getMultiTimer();
    EstopEnable = eeprom.getEstopEn();
    linkEn = eeprom.getLinkEn();
    eeprom.getLinkAnalog(analogLink,analogLinkEn);
    eeprom.getLinkDigital(digitalLink,digitalLinkEn);
    //Multi temp/hum
    
    //DAC
    float Temp7[8];
    float Temp8[8];
    uint8_t Temp9[8];
    eeprom.getDacStartPot(Temp7);
    dac.setStartPotAll(Temp7);
    eeprom.getDacSpan(Temp9);
    dac.setSpanAll(Temp9);
    eeprom.getDacCal(Temp7,Temp8);
    dac.setCalAll(Temp7, Temp8);
    eeprom.getDacEstopMode(EstopOutputASettings);
    eeprom.getDacEstopSetpoint(EstopOutputASetting);
    multiUpdateSettingAout = eeprom.getDacMultiEn();
    
    //ADC
    float Temp4[16];
    float Temp5[16];
    uint8_t Temp6[16];
    eeprom.getAdcCal(Temp4,Temp5);
    adc.setCalAll(Temp4, Temp5);
    eeprom.getAdcSpan(Temp6);
    adc.setSpanAll(Temp6);
    eeprom.getAdcIntMode(Temp6);
    adc.setIntModeAll(Temp6);
    eeprom.getAdcIntSetpoint(Temp4,Temp5);
    adc.setIntSetpointAll(Temp4,Temp5);
    adc.setOversampling(eeprom.getAdcOS());
    multiUpdateSettingAin = eeprom.getAdcMultiEn();
    eeprom.getAdcEstopMode(EstopInputASettings);
    eeprom.getAdcEstopSetpoint(Temp4,Temp5);
    for (int i=0; i<16; i++) {
        EstopInputASetting[i][0] = Temp4[i];
        EstopInputASetting[i][1] = Temp5[i];
    }
    adc.setSumEnAll(eeprom.getAdcSumEn());
    eeprom.getAdcSumSource(Temp6);
    adc.setSumChAll(Temp6);
    eeprom.getAdcSumFactor(Temp4);
    adc.setSumFactorAll(Temp4);
    
    //GPIO
    uint8_t Temp1[32];
    uint8_t Temp2[32];
    bool Temp3[32];
    eeprom.getGpioPinmode(Temp1,Temp2);
    gpio.setPinmodeAll(Temp1,Temp2);
    eeprom.getGpioOutput(Temp3);
    gpio.setOutputAll(Temp3);
    multiUpdateSettingDin = eeprom.getGpioMulti();
    EstopInputPinSetting = eeprom.getGpioEstopInEn();
    EstopInputSetting = eeprom.getGpioEstopInMode();
    EstopOutputPinSetting = eeprom.getGpioEstopOutMode();
    EstopOutputSetting = eeprom.getGpioEstopOutSet(); 
    gpio.setInvertAll(eeprom.getGpioInvert());
    
    //ENV
    eeprom.getEnvEn(envEn); 
    multiUpdateSettingTemp = eeprom.getEnvMulti();
    if (envEn[0]) BME280_0.initialize();
    #if ESPINNING != 3
        if (envEn[1]) BME280_1.initialize();
    #endif
    
    //MONITOR
    monitorEn = eeprom.getMonitorEn();
    monitorState = eeprom.getMonitorState();
    monitorBlinkPeriod = eeprom.getMonitorPeriod();
    monitorOutputPin = eeprom.getMonitorOutputPin();
    eeprom.getMonInEn(monitorInputEn);
    eeprom.getMonLower(monitorLower);
    eeprom.getMonUpper(monitorUpper);
    
    //UART Passthrough
    uint32_t UART_temp[7];
    for (int i=0; i<3; i++) {
        eeprom.getPassthrough(i,UART_temp);
        //pc.printf("EN: %d, Baud: %d, Length: %d, Parit: %d, Stopbits: %d, Newline: %c, Control: %d\n",UART_temp[0],UART_temp[1],UART_temp[2],UART_temp[3],UART_temp[4],UART_temp[5],UART_temp[6]);
        PT_En[i] = UART_temp[0];
        PT_Baud[i] = UART_temp[1];
        PT_Length[i] = UART_temp[2];
        PT_Parity[i] = UART_temp[3];
        PT_StopBits[i] = UART_temp[4];
        PT_Newline[i] = UART_temp[5];
        PT_Control[i] = UART_temp[6];
    }
}

void passthrough(string channel, string data1= "", string data2= "", string data3= "", string data4= "", string data5= "", string data6= "", string data7= "", string data8= ""){
    uint8_t i_channel = stringToInteger(channel.c_str(),1,0);
    if (PT_En[i_channel-1]) {
        string message = data1;
        if (data2 != "") {message.append(" "); message.append(data2);}
        if (data3 != "") {message.append(" "); message.append(data3);}
        if (data4 != "") {message.append(" "); message.append(data4);}
        if (data5 != "") {message.append(" "); message.append(data5);}
        if (data6 != "") {message.append(" "); message.append(data6);}
        if (data7 != "") {message.append(" "); message.append(data7);}
        if (channel == "0") {Error(1);}
        else if (channel == "1") {UART1.printf(message.c_str()); UART1.printf("%c",PT_Newline[0]);}
        else if (channel == "2") {UART2.printf(message.c_str()); UART2.printf("%c",PT_Newline[1]);}
        else if (channel == "3") {UART3.printf(message.c_str()); UART3.printf("%c",PT_Newline[2]);}
        else Error(1);
    }
    else {
        Error("Passthrough not enabled");
    }
}

#if ESPINNING == 2
    int pumpState = 0;
    int Zlocation = 0;
    bool zAxis = false;
    int WDlocation = 0;
    bool WD = false;
    int OSlocation = 0;
    bool OS = true;
#endif

void passthroughReceive(){
        if(PT_En[0] && UART1.readable()){
            bool passThrough = false;
            char received = UART1.getc();
            #if ESPINNING == 2
                if (received == 'Z') {
                    Zlocation = PT1_BufferCounter;
                    zAxis = true;
                }
                if (received == 'W') {
                    WDlocation = PT1_BufferCounter;
                    WD = true;
                }
                if (received == 'O') {
                    OSlocation = PT1_BufferCounter;
                    OS = true;
                }
            #endif
            if (received == '\n' || received == '\r') {
                string message = "";
                for (int i=0; i<PT1_BufferCounter; i++) message+=(PT1_Buffer[i]);
                //pc.printf("Message from UART1: %s\n",message.c_str());
                if (PT1_BufferCounter > 0) {
                    #if ESPINNING == 2
                    if (zAxis && WD && OS) {
                        passThrough = true;
                        string zAxisMessage = "";
                        string WDmessage = "";
                        string OSmessage = "";
                        for (int i=(Zlocation+3); i<PT1_BufferCounter; i++) {
                            if (message[i] == ' ') break;
                            zAxisMessage += message[i];
                        }
                        for (int i=(WDlocation+4); i<PT1_BufferCounter; i++) {
                            if (message[i] == ' ') break;
                            WDmessage += message[i];
                        }
                        for (int i=(OSlocation+4); i<PT1_BufferCounter; i++) {
                            if (message[i] == ' ') break;
                            OSmessage += message[i];
                        }
                        UART2.printf("STAGE Z %.2f WD %.2f OS %.2f\n",atof(zAxisMessage.c_str()),atof(WDmessage.c_str()),atof(OSmessage.c_str()));                       
                        zAxis = false;
                        WD = false;
                        OS = false;
                    } 
                    #endif
                    string target = "";
                    for (int i=0; i<PT1_BufferCounter; i++){
                        if(message[i]=='P' && message[i+1]=='T' && message[i+2] == ' ') {
                            passThrough = true;
                            target +=message[i+3];
                            string messageNew = "";
                            for (int j=(i+5); j<(PT1_BufferCounter-i); j++) messageNew+=message[j];
                            if (DEBUG) pc.printf("DEBUG: Passthrough from PT1 to: %s, message: %s[end]\n",target.c_str(),messageNew.c_str());
                            passthrough(target.c_str(),messageNew.c_str());
                            target="";
                            PT1_BufferCounter=0;
                        }
                    }
                    if (passThrough == false) {
                        if (DEBUG) pc.printf("FROM PT1: %s\n",message.c_str());
                        if (PT_Control[0]) messageDecoder(message.c_str());
                    }
                }
                PT1_BufferCounter=0;
            }
            else {
                PT1_Buffer[PT1_BufferCounter]= received;
                PT1_BufferCounter++;
            }
        }

        if(PT_En[1] && UART2.readable()){
            bool passThrough = false;
            char received = UART2.getc();
            if (received == '\n' || received == '\r') {
                string message = "";
                //pc.printf("Buffer counter: %d\n",PT2_BufferCounter);
                for (int i=0; i<PT2_BufferCounter; i++) message+=(PT2_Buffer[i]);
                //pc.printf("Message from UART2: %s\n",message.c_str());
                if (PT2_BufferCounter > 0) {
                    //pc.printf("0: %c, 1: %c, 2: %c, 3: %c, 4: %c\n",message[0],message[1],message[2],message[3],message[4]);
                    string target = "";
                    if(message[0]=='P' && message[1]=='T' && message[2] == ' ') {
                        passThrough = true;
                        target +=message[3];
                        string messageNew = "";
                        //PT2_Buffer& erase (0, 5);
                        for (int j=5; j<PT2_BufferCounter; j++) messageNew+=message[j];
                        if (DEBUG) pc.printf("DEBUG: Passthrough from PT2 to: %s, message: %s[end]\n",target.c_str(),messageNew.c_str());
                        passthrough(target.c_str(),messageNew.c_str());
                        target="";
                        PT2_BufferCounter=0;
                    }
                    if (passThrough == false) {
                        //pc.printf("FROM PT2: %s\n",message.c_str());
                        PT2_BufferCounter=0;
                        if (PT_Control[1]) messageDecoder(message.c_str());
                    }
                }
                PT2_BufferCounter=0;
            }
            else {
                if (received>31 && received<127) {
                    PT2_Buffer[PT2_BufferCounter]= received;
                    PT2_BufferCounter++;
                }
            }
        }
        
        if(PT_En[2] && UART3.readable()){
           // bool passThrough = false;
            char received = UART3.getc();
            #if ESPINNING == 2 //glovebox system
            if (received == '*' || received == ':' || received == '/'  || received == '^') pumpState = 0; //off
            else if (received == '>') pumpState = 1; //infusing
            else if (received == '<') pumpState = 1; //refilling
            #endif
            
            if (received == '\n' || received == '\r') {
                string message = "";
                for (int i=0; i<PT3_BufferCounter; i++) message+=(PT3_Buffer[i]);
                //pc.printf("Message from UART3: %s\n",message.c_str());
                if (PT3_BufferCounter > 0) {
                    //pc.printf("Buffer counter: %d\tMessage: %s\n",PT3_BufferCounter,message.c_str());
                    //pc.printf("0: %c, 1: %c, 2: %c, 3: %c, 4: %c\n\n",message[0],message[1],message[2],message[3],message[4]);
                    if (message[0] == ' ' && message[1] == ' ') {
                        //passThrough = true;
                        string delivered = "";
                        for (int i=2; i<PT3_BufferCounter; i++) {
                            if ((message[i] >= '0' || message[i] <= '9') || message[i] == '.') delivered += message[i];
                        }
                        //pc.printf("Delivered: %s\n",delivered.c_str());
                       
                        #if ESPINNING == 2
                            UART2.printf("PUMP STATE %d DEL %.4f\n",pumpState,atof(delivered.c_str()));
                        #endif
                        
                    }
                }
                PT3_BufferCounter=0;
            }
            else {
                PT3_Buffer[PT3_BufferCounter]= received;
                PT3_BufferCounter++;
            }
        }
}

bool checkCommand(char check, char correct, bool error=false){
    if (check != correct) {
        if (error) Error(0);
        return false;
    }
    else return true;
}

void printOK(){
    pc.printf("OK\n"); 
}

void setAnalogPot(string data1, string data2){
    if (checkCommand(data1[0],'A',1)==false) return;
    if (checkCommand(data1[1],'O',1)==false) return;
    uint8_t channel = stringToInteger(data1.c_str(),2,2);
    if (channel > 7) {Error(1); return;}
    dac.setOutput(channel, atof(data2.c_str()));
    printOK();
}

void getAnalogPot(string data) {
    bool input;
    if (checkCommand(data[0],'A',1)==false) return;
    if (checkCommand(data[1],'I')==true) input = true;
    else if (checkCommand(data[1],'O')==true) input = false;
    else {Error(0); return;}
    uint8_t channel = stringToInteger(data.c_str(),3,2);
    if (input && channel > 15) {Error(1); return;}
    if (input == false && channel > 7) {Error(1); return;}    
    float received; 
    if (input) received = adc.getMeasurement(channel);
    else received = dac.getOutput(channel);
    pc.printf("POT %s %f\n",data.c_str(),received);  
}

void setAnalogSpan(string data1, string data2) {
    bool input;
    if (checkCommand(data1[0],'A',1)==false) return;
    if (checkCommand(data1[1],'I')==true) input = true;
    else if (checkCommand(data1[1],'O')==true) input = false;
    else {Error(0); return;}
    uint8_t channel = stringToInteger(data1.c_str(),3,2);
    if (input && channel > 16) {Error(1); return;}
    if (input == 0 && channel > 8) {Error(1); return;} 
    uint8_t span = stringToInteger(data2.c_str(),2,0);
    if (span > 2 && input == 1) {Error(3); return;}
    else if (span > 4 && input == 0) {Error(3); return;}
    if (input) adc.setSpan(channel, span);
    else dac.setSpan(channel, span);
    printOK();
}

void getAnalogSpan(string data) {
    uint8_t input;
    if (data[0] != 'A') {Error(0); return;}
    if (data[1] == 'I') input = 1;
    else if (data[1] == 'O') input = 0;
    else {Error(0); return;}
    uint8_t channel = stringToInteger(data.c_str(),3,2);
    if (input && channel > 15) {Error(1); return;}
    if (input == 0 && channel > 7) {Error(1); return;}    
    uint8_t span;
    if (input) span = adc.getSpan(channel);
    else span = dac.getSpan(channel);
    pc.printf("SPAN %s %d\n",data.c_str(),span);  
}

void getCalibration(string data) {
    uint8_t input;
    if (data[0] != 'A') {Error(0); return;}
    if (data[1] == 'I') input = 1;
    else if (data[1] == 'O') input = 0;
    else {Error(0); return;}
    uint8_t channel = stringToInteger(data.c_str(),3,2);
    if (input && channel > 15) {Error(1); return;}
    if (input == 0 && channel > 7) {Error(1); return;}    
    float A, B;
    if (input) adc.getCalibration(channel, A, B);
    else dac.getCalibration(channel, A, B);
    pc.printf("CAL %s %f %f\n",data.c_str(),A,B);  
}

void setCalibration(string data, string A, string B) {
    uint8_t input;
    if (data[0] != 'A') {Error(0); return;}
    if (data[1] == 'I') input = 1;
    else if (data[1] == 'O') input = 0;
    else {Error(0); return;}
    uint8_t channel = stringToInteger(data.c_str(),3,2);
    if (input && channel > 16) {Error(1); return;}
    if (input == 0 && channel > 8) {Error(1); return;}
    if (input) adc.setCalibration(channel, atof(A.c_str()), atof(B.c_str()));
    else dac.setCalibration(channel, atof(A.c_str()), atof(B.c_str()));
    printOK();
}

void setSum(string data1,string data2, string data3, string data4){
    if (data1[0] != 'A') {Error(1); return;}
    bool targetInput;
    if (data1[1] == 'I') targetInput = true;
    else if (data1[1] == 'O') targetInput = false;
    else {Error(1); return;}
    uint8_t channelTarget = stringToInteger(data1.c_str(),3,2);
    if ((targetInput == 1 && channelTarget > 15) || (targetInput == 0 && channelTarget > 7)) {Error(1); return;}
    
    if (data2 == "EN") {
        bool en;
        if (data3[0] == '1') en = true;
        else if (data3[0] == '0') en = false;
        else {Error(4); return;}
        if (targetInput == 1) adc.setSumEn(channelTarget,en);
        printOK();
        return;
    }
    else {
        if (data2[0] != 'A') {Error(1); return;}
        bool sourceInput;
        if (data2[1] == 'I') sourceInput = true;
        else if (data2[1] == 'O') sourceInput = false;
        else {Error(1); return;}
        uint8_t channelSource = stringToInteger(data2.c_str(),3,2);
        if ((sourceInput == 1 && channelSource > 15) || (sourceInput == 0 && channelSource > 7)) {Error(1); return;}
        if (sourceInput)    channelSource += 8;
        if (targetInput) {
            adc.setSumCh(channelTarget, channelSource);
            adc.setSumFactor(channelTarget, atof(data3.c_str()));
        }
        else {
            //dac.setSumCh(channelTarget, channelSource);
            //dac.setSumFactor(channelTarget, atof(data3.c_str());
        }
        
        printOK();
    }
}

void setOversampling(string data) {
    if (data[0] >= '0' && data[0] <= '7')
        adc.setOversampling(data[0] - '0');
    else {Error("Invalid oversampling rate"); return;}
    printOK();
}

void getOversampling() {
    pc.printf("OVERS %d\n",adc.getOversampling());
}

int8_t getDigitalPin(string data) {
    if (data[0] != 'D') {Error(0); return -1;}
    uint8_t pin = stringToInteger(data.c_str(),3,1);
    if (pin > 31) {Error(2); return -1;}
    return pin;
}
void setDigitalOut(string data1,string data2) {
    int8_t pin = getDigitalPin(data1.c_str());
    if (pin<0) return;
    uint8_t value = stringToInteger(data2.c_str(),2,0);
    if (value > 1) {Error(4); return;}
    if (gpio.setOutput(pin, value)) {Error("Pin is no output"); return;};
    printOK();
}

void getDigitalOut(string data) {
    int8_t pin = getDigitalPin(data.c_str());
    if (pin<0) return;
    uint8_t value = gpio.getOutput(pin);
    if (value > 1){Error("Pin is no output"); return;}
    pc.printf("DOUT %s %d\n",data.c_str(),value);
}

void getDigitalIn(string data) {
    int8_t pin = getDigitalPin(data.c_str());
    if (pin<0) return;
    uint8_t ret = gpio.getInput(pin);
    if (ret == 2) {Error("Pin is no input"); return;}
    pc.printf("DIN %s %d\n",data.c_str(),ret);
}

void setPinMode(string data1,string data2) {
    int8_t pin = getDigitalPin(data1.c_str());
    if (pin<0) return;
    uint8_t mode = stringToInteger(data2.c_str(),2,0);
    if (mode > 7) {Error(4); return;}
    //pc.printf("%d\n",LPC_PINCON->PINSEL0);
    if (gpio.setPinMode(pin, mode)) {Error(2); return;};
    //pc.printf("%d\n",LPC_PINCON->PINSEL0);
    printOK();
}

void getPinMode(string data) {
    int8_t pin = getDigitalPin(data.c_str());
    if (pin<0) return;
    pc.printf("PINMODE %s %d\n",data.c_str(),gpio.getPinMode(pin));
}

void setInterrupt(string data1, string data2, string data3, string data4){
    if (data1[0] == 'D') {
        uint8_t pin = stringToInteger(data1.c_str(),3,1);
        if (pin > 31) {Error(2); return;}
        uint8_t mode = stringToInteger(data2.c_str(),2,0);
        if (mode > 3) {Error(4); return;}
        uint8_t ret = gpio.setInterrupt(pin, mode);
        if (ret == 2) {Error("Pin is no input"); return;}
    }
    if (data1[0] == 'A') {
        if (data1[1] != 'I') {Error(0); return;}
        uint8_t channel = stringToInteger(data1.c_str(),3,2);
        if (channel > 16) {Error(2); return;}
        uint8_t mode = stringToInteger(data2.c_str(),2,0);
        if (mode > 4) {Error(4); return;}
        float value = atof(data3.c_str());
        float range = atof(data4.c_str());
        adc.setInterrupt(channel, mode, value,range);
    }
    pc.printf("OK\n");
}

void getSettings() {
    pc.printf("\n---------------------------------------------------------\n");
    pc.printf("%s\nHardware version: \t%s\nSoftware version: \t%s\nSoftware date: \t\t%s\n",NAME,HWVERSION,SWVERSION,DATE);
    pc.printf("---------------------------------------------------------\nGeneric settings\n");
    pc.printf("Baud rate: %d\n",SerialBaud);
    pc.printf("Multiupdate enable: %d\n",multiUpdateEnable[0]);
    pc.printf("Multiupdate interval: %d ms\n",multiUpdateInterval);
    pc.printf("Emergency stop enable: %d\n",EstopEnable);
    pc.printf("Monitor enable: %d\nMonitor output pin: %d\nMonitor output state: %d\nMonitor blink period: %d ms\n",monitorEn,monitorOutputPin,monitorState,monitorBlinkPeriod*50);
    pc.printf("Link enable: %d\n",linkEn);
    pc.printf("---------------------------------------------------------\nAnalog outputs\nChannel\t\tSpan\t\tCalA\t\tCalB\t\tSumEn\t\tSumSource\tSumFactor\tOutput\t\tMultiEn\t\tLinkEn\t\tLinkCh\t\tEstopMode\tEstopSetpoint\n");
    for (int i=0; i<8; i++) {
        float A,B;
        dac.getCalibration(i, A, B);
        pc.printf("%d\t\t",i);
        uint8_t span = dac.getSpan(i);
        if (span == 0) pc.printf("+-2.5V");
        else if (span == 1) pc.printf("+-5V");
        else if (span == 2) pc.printf("+-10V");
        else if (span == 3) pc.printf("0-5V");
        else if (span == 4) pc.printf("0-10V");
        else pc.printf("Err");
        pc.printf("\t\t%f\t%f\t",A,B);
        if ((analogOutSumEn<<i)&1)  pc.printf("Enabled\t\t");
        else                        pc.printf("Disabled\t");
        if (analogOutSumSource[i] > 7) pc.printf("AI%d",analogOutSumSource[i]-8);
        else                        pc.printf("AO%d",(analogOutSumSource[i]));
        pc.printf("\t\t%f\t%f\t",analogOutSumFactor[i],dac.getOutput(i));
            
        
        
        if (((multiUpdateSettingAout>>i)&1) == 0) pc.printf("Off\t\t");
        else if (((multiUpdateSettingAout>>i)&1) == 1) pc.printf("On\t\t");
        if (analogLinkEn[i]) pc.printf("On\t\t");
        else pc.printf("Off\t\t");
        pc.printf("AI%d\t\t",analogLink[i]);
        if (EstopOutputASettings[i] == 0) pc.printf("Off");
        else if (EstopOutputASettings[i] == 1) pc.printf("On");
        else pc.printf("Err");
        pc.printf("\t\t%f\n",EstopOutputASetting[i]);
    }
    pc.printf("---------------------------------------------------------\nAnalog inputs\nChannel\t\tSpan\t\tCalA\t\tCalB\t\tSumEn\t\tSumSource\tSumFactor\tInput\t\tMultiEn\t\tEstopMode\tEstopSP\t\tEstopRange\tInMode\t\tIntSP\t\tIntRange\tMonitorEn\tMonitor Lower\t\tMonitor Upper\n");
    for (int i=0; i<16; i++) {
        float A,B;
        adc.getCalibration(i, A, B);
        float intSetpoint;
        float intRange;
        uint8_t intMode = adc.getInterrupt(i, intSetpoint, intRange);
        
        pc.printf("%d\t\t",i);
        uint8_t span = adc.getSpan(i);
        if (span == 0) pc.printf("+-2.5V");
        else if (span == 1) pc.printf("+-5V");
        else if (span == 2) pc.printf("+-10V");
        else pc.printf("Err");
        
        pc.printf("\t\t%f\t%f\t",A,B);
        if (adc.getSumEn(i) == 1)     pc.printf("Enabled\t\t");
        else                     pc.printf("Disabled\t");
        if (adc.getSumCh(i) > 7) pc.printf("AI%d",adc.getSumCh(i)-8);
        else                     pc.printf("AO%d",adc.getSumCh(i));
        pc.printf("\t\t%f\t%f\t",adc.getSumFactor(i),adc.getMeasurement(i));
        
        if (((multiUpdateSettingAin>>i)&1) == 0) pc.printf("Off");
        else if (((multiUpdateSettingAin>>i)&1) == 1) pc.printf("On");
        else pc.printf("Err");
        pc.printf("\t\t");
        if (EstopInputASettings[i] == 0) pc.printf("Off");
        else if (EstopInputASettings[i] == 1) pc.printf("In<SP");
        else if (EstopInputASettings[i] == 2) pc.printf("In>SP");
        else if (EstopInputASettings[i] == 3) pc.printf("In<SP+R");
        else if (EstopInputASettings[i] == 4) pc.printf("In>SP+R");
        else pc.printf("Err");
        pc.printf("\t\t%f\t%f\t", EstopInputASetting[i][0], EstopInputASetting[i][1]);
        if (intMode == 0) pc.printf("Off");
        else if (intMode == 1) pc.printf("In<SP");
        else if (intMode == 2) pc.printf("In>SP");
        else if (intMode == 3) pc.printf("In<SP+R");
        else if (intMode == 4) pc.printf("In>SP+R");
        else pc.printf("Err");
        pc.printf("\t\t%f\t%f", intSetpoint, intRange);
        pc.printf("\t%d\t\t%f\t\t%f\n",monitorInputEn[i],monitorLower[i],monitorUpper[i]);
    }
    uint8_t OS = adc.getOversampling();
    uint8_t OSvalue = 2;
    for (int i=0; i<OS; i++) OSvalue *= 2;
    OSvalue /= 2;
    if (OS == 0) OSvalue = 0;
    if (OS == 7) OSvalue = 128;
    pc.printf("Oversampling rate: %d\n",OSvalue);
    pc.printf("---------------------------------------------------------\nGPIO\nPin\t\tPinMode\t\tState\t\tInvert\t\tIntMode\t\tMultiEn\t\tLinkEn\t\tLinkPin\t\tEstopInEn\tEstopInTrig\tEstopOutEn\tEstopOutSet\n");
    for (int i=0; i<32; i++) {
        pc.printf("%d\t\t",i);
        uint8_t pinMode = gpio.getPinMode(i);
        if (pinMode == 0) pc.printf("In");
        else if (pinMode == 1) pc.printf("In+PU");
        else if (pinMode == 2) pc.printf("In+PD");
        else if (pinMode == 3) pc.printf("Out");
        else if (pinMode == 4) pc.printf("PWM");
        else if (pinMode == 5) pc.printf("I2C");
        else if (pinMode == 6) pc.printf("SPI");
        else if (pinMode == 7) pc.printf("UART");
        else pc.printf("Err");
        pc.printf("\t\t");
        if ((pinMode<3 && gpio.getInput(i) == 0) || (pinMode==3 && gpio.getOutput(i) == 0)) pc.printf("Low");
        else if ((pinMode<3 && gpio.getInput(i) == 1) || (pinMode==3 && gpio.getOutput(i) == 1)) pc.printf("High");
        else pc.printf("");
        pc.printf("\t\t");
        if (gpio.getInvert(i)) pc.printf("Yes\t\t");
        else pc.printf("No\t\t");        
        
        uint8_t intMode = gpio.getInterrupt(i);
        if (intMode == 0) pc.printf("Off");
        else if (intMode == 1) pc.printf("Any");
        else if (intMode == 2) pc.printf("Rising");
        else if (intMode == 3) pc.printf("Falling");
        else pc.printf("Err");
        pc.printf("\t\t");
        if (((multiUpdateSettingDin>>i)&1) == 0) pc.printf("Off");
        else if (((multiUpdateSettingDin>>i)&1) == 1) pc.printf("On");
        else pc.printf("Err");
        pc.printf("\t\t");
        if (digitalLinkEn[i]) pc.printf("On\t\t");
        else pc.printf("Off\t\t");
        pc.printf("D%d\t\t",digitalLink[i]);
        if (((EstopInputPinSetting>>i)&1) == 0) pc.printf("Off");
        else if (((EstopInputPinSetting>>i)&1) == 1) pc.printf("On");
        else pc.printf("Err");
        pc.printf("\t\t");
        if (((EstopInputSetting>>i)&1) == 0) pc.printf("Low");
        else if (((EstopInputSetting>>i)&1) == 1) pc.printf("High");
        else pc.printf("Err");
        pc.printf("\t\t");
        if (((EstopOutputPinSetting>>i)&1) == 0) pc.printf("Off");
        else if (((EstopOutputPinSetting>>i)&1) == 1) pc.printf("On");
        else pc.printf("Err");
        pc.printf("\t\t");
        if (((EstopOutputSetting>>i)&1) == 0) pc.printf("Low");
        else if (((EstopOutputSetting>>i)&1) == 1) pc.printf("High");
        else pc.printf("Err");
        pc.printf("\n");
    }
    pc.printf("---------------------------------------------------------\nEnvironmental Sensors\nSensor\t\tEnabled\t\tTemp\t\tMultiEn Temp\tHum\t\tMultiEn Hum\tPress\t\tMultiEn Press\n");

    if (envEn[0]==1){
        pc.printf("0\t\tEnabled\t\t");
        pc.printf("%.2f\t\t",BME280_0.getTemperature());
        if (multiUpdateSettingTemp&1 == 1)  pc.printf("On\t\t");
        else                                pc.printf("Off\t\t");
        pc.printf("%.2f\t\t",BME280_0.getHumidity());
        if ((multiUpdateSettingTemp>>1)&1 == 1) pc.printf("On\t\t");
        else                                    pc.printf("Off\t\t");
        pc.printf("%.2f\t\t",BME280_0.getPressure());
        if ((multiUpdateSettingTemp>>2)&1 == 1) pc.printf("On\n");
        else                                    pc.printf("Off\n");
    }
    else {
        pc.printf("0\t\tDisabled\tNA\t\t");
        if (multiUpdateSettingTemp&1 == 1)  pc.printf("On\t\t");
        else                                pc.printf("Off\t\t");
        pc.printf("NA\t\t");
        if ((multiUpdateSettingTemp>>1)&1 == 1) pc.printf("On\t\t");
        else                                    pc.printf("Off\t\t");
        pc.printf("NA\t\t");
        if ((multiUpdateSettingTemp>>2)&1 == 1) pc.printf("On\n");
        else                                    pc.printf("Off\n");
    }
    
    if (envEn[1]==1){
        #if ESPINNING != 3
        pc.printf("1\t\tEnabled\t\t");
        pc.printf("%.2f\t\t",BME280_1.getTemperature());
        if ((multiUpdateSettingTemp>>3)&1 == 1)  pc.printf("On\t\t");
        else                                pc.printf("Off\t\t");
        pc.printf("%.2f\t\t",BME280_1.getHumidity());
        if ((multiUpdateSettingTemp>>4)&1 == 1) pc.printf("On\t\t");
        else                                    pc.printf("Off\t\t");
        pc.printf("%.2f\t\t",BME280_1.getPressure());
        if ((multiUpdateSettingTemp>>5)&1 == 1) pc.printf("On\n");
        else                                    pc.printf("Off\n");
        #endif
    }
    else {
        pc.printf("0\t\tDisabled\tNA\t\t");
        if ((multiUpdateSettingTemp>>3)&1 == 1)  pc.printf("On\t\t");
        else                                pc.printf("Off\t\t");
        pc.printf("NA\t\t");
        if ((multiUpdateSettingTemp>>4)&1 == 1) pc.printf("On\t\t");
        else                                    pc.printf("Off\t\t");
        pc.printf("NA\t\t");
        if ((multiUpdateSettingTemp>>5)&1 == 1) pc.printf("On\n");
        else                                    pc.printf("Off\n");
    }
    pc.printf("---------------------------------------------------------\nUART Passthrough\nChannel\t\tEnabled\t\tBaud\t\tData length\tParity\t\tStop Bits\tNewline Char\tControl\t\tMulti\n");
    for (int i=0; i<3; i++){
        pc.printf("%d\t\t",i+1);
        if(PT_En[i]) pc.printf("Enabled\t");
        else pc.printf("Disabled");
        pc.printf("\t%d\t\t%d\t\t",PT_Baud[i],PT_Length[i]);
        if (PT_Parity[i] == 0)      pc.printf("None");
        else if (PT_Parity[i] == 1) pc.printf("Odd");
        else if (PT_Parity[i] == 2) pc.printf("Even");
        else if (PT_Parity[i] == 3) pc.printf("Forced1");
        else if (PT_Parity[i] == 4) pc.printf("Forced0");
        pc.printf("\t\t%d\t\t",PT_StopBits[i]);
        if (PT_Newline[i] == '\n') pc.printf("<NL>");
        else pc.printf("<CR>");
        if (PT_Control[i]) pc.printf("\t\tYes");
        else pc.printf("\t\tNo");
        if(multiUpdateEnable[i+1]) pc.printf("\t\tYes\n");
        else pc.printf("\t\tNo\n");
        
    }
    pc.printf("---------------------------------------------------------\n\n");
}
/*
 if (multiUpdateSettingTemp&1 == 1) pc.printf("T0,%.2f,",BME280_0.getTemperature());
        if ((multiUpdateSettingTemp>>1)&1 == 1) pc.printf("H0,%.2f,",BME280_0.getHumidity());
        if ((multiUpdateSettingTemp>>2)&1 == 1) pc.printf("P0,%.2f,",BME280_0.getPressure());
    //}
    //if (envEn[1] == 1) {
        if ((multiUpdateSettingTemp>>3)&1 == 1) pc.printf("T1,%.2f,",BME280_1.getTemperature());
        if ((multiUpdateSettingTemp>>4)&1 == 1) pc.printf("H1,%.2f,",BME280_1.getHumidity());
        if ((multiUpdateSettingTemp>>5)&1 == 1) pc.printf("P1,%.2f,",BME280_1.getPressure());
        */
 /*
    interrupt modes:
    0 = disabled
    1 = Any edge
    2 = Rising edge
    3 = Falling edge
*/

void checkInt() {
    if (gpio.checkInterruptEnable() == 1) 
        for (int i=0; i<32; i++) {
            bool value = 0;
            bool ret = gpio.checkInterrupt(i,value);
            if (ret) pc.printf("INT D%d %d\n",i,value);
        }
    if (adc.checkInterruptEnable() == 1)
        for (int i=0; i<16; i++) {
            float value = 0;
            bool ret = adc.checkInterrupt(i, value);
            if (ret) pc.printf("INT AI%d %f\n",i,value);
        }
}

#if ESPINNING == 2
int screenSend = 0;
void screenUpdate(){
    if (screenSend == 4) {
        UART3.printf("DEL\r");
        screenSend = 0;
    }
    else screenSend++;
}
#endif

void multiUpdate() {
    //string message = "MULTI ";
    string buffer = "MULTI ";
    char bufferTemp[20];
    for (int i=0; i<16; i++) {
        bool ret = (multiUpdateSettingAin>>i)&1;
        if (ret) {
            sprintf(bufferTemp,"AI%d,%f,",i,adc.getMeasurement(i));
            buffer+=bufferTemp;
        }
    }
    for (int i=0; i<8; i++) {
        bool ret = (multiUpdateSettingAout>>i)&1;
        if (ret) {
            sprintf(bufferTemp,"AO%d,%f,",i,dac.getOutput(i));
            buffer+=bufferTemp;
        }
    }
    for (int i=0; i<32; i++) {
        bool ret = (multiUpdateSettingDin>>i)&1;
        if (ret == 1 && gpio.getPinMode(i) < 3) {
            sprintf(bufferTemp,"D%d,%d,",i,gpio.getInput(i));
            buffer+=bufferTemp;
        }
        else if (ret == 1 && gpio.getPinMode(i) == 3){
            sprintf(bufferTemp,"D%d,%d,",i,gpio.getOutput(i));
            buffer+=bufferTemp;
        }
    }
    if (multiUpdateSettingTemp&1 == 1) {
        sprintf(bufferTemp,"T0,%.2f,",BME280_0.getTemperature());
        buffer+=bufferTemp;
    }
    if ((multiUpdateSettingTemp>>1)&1 == 1) {
        sprintf(bufferTemp,"H0,%.2f,",BME280_0.getHumidity());
        buffer+=bufferTemp;
    }
    if ((multiUpdateSettingTemp>>2)&1 == 1) {
        sprintf(bufferTemp,"P0,%.2f,",BME280_0.getPressure());
        buffer+=bufferTemp;
    }
    #if ESPINNING != 3
    if ((multiUpdateSettingTemp>>3)&1 == 1) {
        sprintf(bufferTemp,"T1,%.2f,",BME280_1.getTemperature());
        buffer+=bufferTemp;
    }
    if ((multiUpdateSettingTemp>>4)&1 == 1) {
        sprintf(bufferTemp,"H1,%.2f,",BME280_1.getHumidity());
        buffer+=bufferTemp;
    }
    if ((multiUpdateSettingTemp>>5)&1 == 1) {
        sprintf(bufferTemp,"P1,%.2f,",BME280_1.getPressure());
        buffer+=bufferTemp;
    }
    #endif
    #if ESPINNING == 2
        sprintf(bufferTemp,"M,%d,",gpio.getOutput(monitorOutputPin));
        buffer+=bufferTemp;
    #endif
    sprintf(bufferTemp,"E,%d\n",EstopTriggered);
    buffer+=bufferTemp;
    buffer+="\n";
    if (multiUpdateEnable[0]) pc.printf("%s",buffer.c_str());
    if (PT_En[0] && multiUpdateEnable[1]) UART1.printf("%s",buffer.c_str());
    if (PT_En[1] && multiUpdateEnable[2]) UART2.printf("%s",buffer.c_str());
    if (PT_En[2] && multiUpdateEnable[3]) UART3.printf("%s",buffer.c_str());
}

void setMultiUpdateData(uint32_t data, uint8_t data2, bool value) {
    if (data2 == 0 && value == 1) multiUpdateSettingAin|= data;                                  //analog inputs
    else if (data2 == 0 && value == 0) multiUpdateSettingAin = ~(~multiUpdateSettingAin|data);  
    else if (data2 == 1 && value == 1) multiUpdateSettingAout|= data;                            //analog outputs  
    else if (data2 == 1 && value == 0) multiUpdateSettingAout = ~(~multiUpdateSettingAout|data); 
    else if (data2 == 2 && value == 1) multiUpdateSettingDin|= data;                             //digital inputs
    else if (data2 == 2 && value == 0) multiUpdateSettingDin = ~(~multiUpdateSettingDin|data);  
    else if (data2 == 3 && value == 1) multiUpdateSettingTemp|= data;                             //temp & hum
    else if (data2 == 3 && value == 0) multiUpdateSettingTemp = ~(~multiUpdateSettingTemp|data);  
}

void getMultiUpdate(string data1, string data2, string data3) {
    if (data1 == "EN") {
        if (data2 == "PT") {
            uint8_t ch = stringToInteger(data3.c_str(),2,0); 
            pc.printf("MULTI EN PT %d %d\n",ch,multiUpdateEnable[ch]);
        }
        else    pc.printf("MULTI EN %d\n", multiUpdateEnable[0]);
        return;
    }
    else if (data1 == "TIMER"){
        pc.printf("MULTI TIMER %d\n", multiUpdateInterval);
        return;
    }
    else if (data1 == "SEL"){
        pc.printf("MULTI SEL ");
        for (int i=0; i<16; i++) {
            bool ret = (multiUpdateSettingAin>>i)&1;
            if (ret) pc.printf("AI%d,",i);
        }
        for (int i=0; i<32; i++) {
            bool ret = (multiUpdateSettingDin>>i)&1;
            if (ret == 1 && gpio.getPinMode(i) < 4) pc.printf("D%d,",i);
        }
        if (multiUpdateSettingTemp&1 == 1) pc.printf("T,");
        if ((multiUpdateSettingTemp>>1)&1 == 1) pc.printf("H,");
        pc.printf("\n");
    }
    else if (data1 == "SINGLE"){
        multiUpdate();
    }
}

void setMultiUpdate(string data1, string data2, string data3, string data4){
    if (data1 == "EN") {
        if (data2 == "PT") {
            uint8_t ch = stringToInteger(data3.c_str(),2,0); 
            uint8_t en = stringToInteger(data4.c_str(),2,0); 
            if (ch > 3) {Error(1); return;}
            if (en > 1) {Error(4); return;}
            multiUpdateEnable[ch] = en;  
            pc.printf("OK\n");
            return; 
        }
        else{
            uint8_t en = stringToInteger(data2.c_str(),2,0); 
            if (en > 1) {Error(4); return;}
            else {
                multiUpdateEnable[0] = en;
                multiUpdateTimer.reset();
                pc.printf("OK\n");
                return;
            }
        }
    }
    else if (data1 == "TIMER") {
        uint32_t ret = stringToInteger(data2.c_str(),10,0);
        if (ret < 4294967296) {
            multiUpdateInterval = ret;
            multiUpdateTimer.reset();
            pc.printf("OK\n");
        }
        return; 
    }
    else if (data1[0] == 'A' && data1[1] == 'I') {
        uint8_t ret = stringToInteger(data1.c_str(),3,2);
        if (ret > 15) {Error(1); return;}
        uint8_t value = stringToInteger(data2.c_str(),2,0);
        if (value != 0 && value != 1) {Error(4); return;}
        setMultiUpdateData(1 << ret,0,value);
        pc.printf("OK\n");
    }
    else if (data1[0] == 'A' && data1[1] == 'O') {
        uint8_t ret = stringToInteger(data1.c_str(),3,2);
        if (ret > 7) {Error(1); return;}
        uint8_t value = stringToInteger(data2.c_str(),2,0);
        if (value != 0 && value != 1) {Error(4); return;}
        setMultiUpdateData(1 << ret,1,value);
        pc.printf("OK\n");
    }
    else if (data1[0] == 'D') {
        uint8_t ret = stringToInteger(data1.c_str(),3,1);
        if (ret > 31) {Error(2); return;}
        uint8_t value = stringToInteger(data2.c_str(),2,0);
        if (value != 0 && value != 1) {Error(4); return;}
        setMultiUpdateData(1 << ret,2, value);
        pc.printf("OK\n");
    }
    else if (data1 == "TEMP") {
        bool pin = stringToInteger(data2.c_str(),2,0);
        uint8_t value = stringToInteger(data3.c_str(),2,0);
        if ((value != 0 && value != 1) || (pin != 0 && pin != 1)) {Error(4); return;}
        setMultiUpdateData(1<<(pin*3),3, value);
        pc.printf("OK\n");
    }
    else if (data1 == "HUM") {
        bool pin = stringToInteger(data2.c_str(),2,0);
        uint8_t value = stringToInteger(data3.c_str(),2,0);
        if ((value != 0 && value != 1) || (pin != 0 && pin != 1)) {Error(4); return;}
        setMultiUpdateData(1<<(1+pin*3),3, value);
        pc.printf("OK\n");
    }
    else if (data1 == "PRESS") {
        bool pin = stringToInteger(data2.c_str(),2,0);
        uint8_t value = stringToInteger(data3.c_str(),2,0);
        if ((value != 0 && value != 1) || (pin != 0 && pin != 1)) {Error(4); return;}
        setMultiUpdateData(1<<(2+pin*3),3, value);
        pc.printf("OK\n");
    }
    else Error(0);
}

void setEstop(string data1, string data2, string data3, string data4, string data5){
    if (data1 == "EN") {                                                        //If enable is to be set
        uint8_t ret = stringToInteger(data2.c_str(),2,0);                       //Get the enable setting
        if (ret > 1) {Error(4); return;}                          //Can only be 0 or 1, else return
        EstopEnable = ret;                                                      //Set the variable
        pc.printf("OK\n");
        return;
    }
    else if (data1 == "CLEAR") {
        EstopFlag = 1;
        EstopTriggered = 0;
        homingEn = 0;
        pc.printf("OK\n");
    }
    else if (data1 == "IN") {                                                   //If Estop inputs are to be set
        if (data2[0] == 'D') {                                                  //If digital in is to be set
            uint8_t pin = stringToInteger(data2.c_str(),3,1);                   //Get the pin
            if (pin > 31) {Error(2); return;}                       //Make sure it's a valid pin
            if (gpio.getPinMode(pin) > 2) {Error("Pin is no input"); return;}   //Make sure pin is set to input
            uint8_t mode = stringToInteger(data3.c_str(),2,0);                  //Get the trigger mode
            if (mode > 1) {Error(4); return;}                     //Can be 0, 1
            uint8_t trigger = stringToInteger(data4.c_str(),2,0);                //Get the trigger state
            if (trigger > 1) {Error(4); return;}                   //Can be 0, 1
            if (mode == 0) {                                                    //If disabled, reset all values
                EstopInputPinSetting = ~(~EstopInputPinSetting|(1<<pin));
                EstopInputSetting = ~(~EstopInputSetting|(1<<pin));
            }
            else { 
                EstopInputPinSetting |= (1<<pin);                               //Else, set the correct bits
                if (trigger) EstopInputSetting |= (1<<pin);
                else EstopInputSetting = ~(~EstopInputSetting|(1<<pin));
            }     
            pc.printf("OK\n");
        }
        else if (data2[0] == 'A') {                                             //If Estop analog inputs are to be set
            if (data2[1] != 'I') {Error(0); return;}            //Make sure analog inputs are requested
            uint8_t channel = stringToInteger(data2.c_str(),2,2);               //Get the requested channel
            if (channel > 15) {Error(1); return;}               //Make sure channel is valid                  
            uint8_t mode = stringToInteger(data3.c_str(),2,0);                  //Get the requested mode
            if (mode > 4) {Error(4); return;}                     //Make sure mode is valid
            EstopInputASettings[channel] = mode;                                 //store Estop mode
            if (mode == 0) {
                EstopInputASetting[channel][0] = 0;                             //if disabled, set setpoint to 0
                EstopInputASetting[channel][1] = 0;                             //if disabled, set range to 0
            }
            else {
                EstopInputASetting[channel][0] = atof(data4.c_str());           //set setpoint
                EstopInputASetting[channel][1] = atof(data5.c_str());           //set range
            }
            pc.printf("OK\n");
        }      
        else {Error(0); return;}
    }
    else if (data1 == "OUT") {                                                  //Set Estop outputs
        if (data2[0] == 'D') {                                                  //Set digital outputs
            uint8_t pin = stringToInteger(data2.c_str(),3,1);                   //Get the requested pin
            if (pin > 31) {Error(2); return;}                       //Make sure pin is valid
            if (gpio.getPinMode(pin) != 3) {Error("Pin is no output"); return;} //Make sure pin is an output
            uint8_t mode = stringToInteger(data3.c_str(),2,0);                  //Get requested mode
            if (mode > 1) {Error(4); return;}                     //Make sure requested mode is valid
            uint8_t setpoint = stringToInteger(data4.c_str(),2,0);                  //Get requested setpoint
            if (setpoint > 1) {Error(4); return;}                     //Make sure requested setpoint is valid
            if (mode == 0) {                                                    //If disabled, reset all values
                EstopOutputPinSetting = ~(~EstopOutputPinSetting|(1<<pin));
                EstopOutputSetting = ~(~EstopOutputSetting|(1<<pin));
            }
            else {                                                              //Else, set the correct bits
                EstopOutputPinSetting |= (1<<pin);
                if (setpoint) EstopOutputSetting |= (1<<pin);
                else EstopOutputSetting = ~(~EstopOutputSetting|(1<<pin));
            }     
            pc.printf("OK\n");
        }
        else if (data2[0] == 'A') {                                             //Set Estop analog outputs
            if (data2[1] != 'O') {Error(0); return;}            //Make sure outputs are selected
            uint8_t channel = stringToInteger(data2.c_str(),2,2);               //Get the channel
            if (channel > 7) {Error(1); return;}                //Make sure the channel is valid
            uint8_t mode = stringToInteger(data3.c_str(),2,0);                  //Get the requested mode
            if (mode > 1) {Error(4); return;}                     //Make sure mode is valid
            EstopOutputASettings[channel] = mode;                               //Sets the mode
            if (mode == 0) EstopOutputASetting[channel] = 0;                    //If disabled, reset the setpoint
            else EstopOutputASetting[channel] = atof(data4.c_str());            //Else, store the requested setpoint
            pc.printf("OK\n");
        }
        else {Error(0); return;}
    } 
}
//EstopOutputASetting[8];   

void getEstop(string data1) {
    /*
    if (data1 == "EN") pc.printf("ESTOP EN %d\n",EstopEnable);
    else if (data1 == "TRIG") pc.printf("ESTOP TRIG %d\n",EstopTriggered);
    else if (data1 == "IN") {
        pc.printf("ESTOP IN ");
        for (int i=0; i<16; i++) if ((EstopInputChSetting>>(i*2))&3 > 0) (pc.printf("AI%d,%d,%f,",i,(EstopInputChSetting>>(i*2))&3,EstopInputASetting[i][0]));
        for (int i=0; i<32; i++) if ((EstopInputPinSetting>>i)&1) (pc.printf("D%d,%d,",i,(EstopInputSetting>>i)&1));
        pc.printf("\n");
    }
    else if (data1 == "OUT") {
        pc.printf("ESTOP OUT ");
        for (int i=0; i<8; i++)  if ((EstopOutputChSetting>>i)&1) (pc.printf("AO%d,%f,",i,EstopOutputASetting[i]));
        for (int i=0; i<32; i++) if ((EstopOutputPinSetting>>i)&1) (pc.printf("D%d,%d,",i,(EstopOutputSetting>>i)&1));
        pc.printf("\n");
    }
    else {Error(0); return;}
    */
}

void EstopTrue() {
    for (int j=0; j<32; j++)
        if ((EstopOutputPinSetting>>j)&1)                           //check if any pin is set as Estop output
            gpio.setOutput(j, (EstopOutputSetting>>j)&1);        //set the output
    for (int j=0; j<8; j++)
        if (EstopOutputASettings[j])                           //check if any analog output is set as Estop output
            dac.setOutput(j, EstopOutputASetting[j]);         //set the output
}

void emergencyStop(){
    EstopTriggered = 1;
    EstopFlag = 0;
    EstopTrue();
    pc.printf("ESTOP");
    #if DEBUG
    pc.printf(" Source: ");
    if (EstopSource == 1) pc.printf("Digital In"); 
    else if (EstopSource == 2) pc.printf("Analog In");
    else if (EstopSource == 3) pc.printf("UART");
    else if (EstopSource == 4) pc.printf("Espinning");
    else pc.printf("Unknown");
    #endif
    pc.printf("\n");  
    #if ESPINNING == 2
        UART2.printf("ESTOP\n");
        UART3.printf("STP\r");
    #endif       
}

bool EstopCheck(){
    if (EstopEnable == 0) return 0;
    for (int i=0; i<32; i++) {                                                  //Check digital inputs                                                
        if ((EstopInputPinSetting>>i)&1)                                         //check if any pin is set as Estop input
            if (((EstopInputSetting>>i)&1) == gpio.getInput(i)){                   //check if the pin state equals the trigger state
                EstopSource = 1;
                emergencyStop();
                return 1;
            }
    }
    for (int i=0; i<16; i++) {                                                  //Check analog inputs
        if (EstopInputASettings[i] > 0) {                                       //If Estop is enabled
            float valueMeasured = adc.getMeasurement(i);                        //Get measurement
            float valueCompare = EstopInputASetting[i][0];                      //Get value to compare to measurement
            float range = EstopInputASetting[i][1];                             //Get range 
            if ( (EstopInputASettings[i] == 1 && valueMeasured < valueCompare)      //smaller than
                || (EstopInputASettings[i] == 2 && valueMeasured > valueCompare)      //bigger than
                || (EstopInputASettings[i] == 3 && valueMeasured > (valueCompare-range) && valueMeasured < (valueCompare+range))  //within range
                || (EstopInputASettings[i] == 4 && (valueMeasured < (valueCompare-range) || valueMeasured > (valueCompare+range))) //outside of range
                ) {  
                EstopSource = 2;  
                emergencyStop();
                return 1;
            }
        }
    }
    return 0;   
}



void setPWM(string data1, string data2, string data3){
    if (data1 == "WIDTH") {
        if (data2[0] != 'D') {Error(2); return;}
        uint8_t pin = stringToInteger(data2.c_str(),3,1);
        if (pin < 2 || (pin > 5 && pin != 26 && pin != 27)) {Error(2); return;}
        if (gpio.getPinMode(pin) != 4) {Error("Pin is no PWM output"); return;}
        float width = atof(data3.c_str());
        if (width < 0.042) {Error(4); return;}
        gpio.setPWMwidth(pin, (uint32_t)(width*1000));
        pc.printf("OK\n");
    }
    if (data1 == "DUTY") {
        if (data2[0] != 'D') {Error(2); return;}
        uint8_t pin = stringToInteger(data2.c_str(),3,1);
        if (pin < 2 || (pin > 5 && pin != 26 && pin != 27)) {Error(2); return;}
        if (gpio.getPinMode(pin) != 4) {Error("Pin is no PWM output"); return;}
        float duty = atof(data3.c_str());
        if (duty < 0 || duty > 100) {Error(4); return;}
        gpio.setPWMduty(pin, duty);
        pc.printf("OK\n");
    }
    if (data1 == "PERIOD") {
        float period = atof(data2.c_str());
        gpio.setPWMperiod((uint32_t)(period*1000));
        if (period < 0.084) {Error(4); return;}
        pc.printf("OK\n");
    }
    if (data1 == "FREQ") {
        float freq = atof(data2.c_str());
        if (freq == 12000000) freq = 11000000;
        if (freq > 5900000 && freq <= 6000000) freq = 5000000;
        if (freq < 0 || freq > 12000000) {Error(4); return;}
        gpio.setPWMfreq(freq);
        pc.printf("OK\n");
    }
}
void getAllEeprom(){
    uint8_t data[32];
    for (int i=0; i<32; i++) data[i] = 0;
    
    pc.printf("Get all EEPROM data:\n\t");
    for (int i=0; i<32; i++) pc.printf("%d\t",i);
    pc.printf("\n");
    for (int i=0; i< 2000; i+=32){
        eeprom.read(i,data,32);
        pc.printf("%d|\t",i);
        for (int j=0; j<32; j++) pc.printf("%d\t",data[j]);
        pc.printf("\n");
    }
}

void getEEPROM(string data){
    if (data == "LOAD") {
        w.kick();
        getAllEeprom();
        pc.printf("OK\n");
    }
    else {Error(0); return;}
}  

void setEEPROM(string data){
    if (data == "SAVE") {
        w.kick(20);
        saveEeprom();
        w.kick(WATCHDOG_TIME);
        pc.printf("OK\n");
    }
    else {Error(0); return;}
}
#define RAMPPERIOD 1
uint32_t rampSteps = 0;
#define NOZZLE_CH 2
#define NOZZLE_Iin_CH 6
#define COLLECTOR_CH 4
#define AUX1_CH 6
#define AUX2_CH 0
uint32_t rampCounter = 0;
float nozzleSteps = 0;
float collectorSteps = 0;
float aux1Steps = 0;
float aux2Steps = 0;
bool rampEnable = 0;

void ramp(){
    if (rampCounter <= rampSteps) {
        dac.setOutput(NOZZLE_CH,dac.getOutput(NOZZLE_CH)+nozzleSteps);
        dac.setOutput(COLLECTOR_CH,dac.getOutput(COLLECTOR_CH)+collectorSteps);
        dac.setOutput(AUX1_CH,dac.getOutput(AUX1_CH)+aux1Steps);
        dac.setOutput(AUX2_CH,dac.getOutput(AUX2_CH)+aux2Steps);
        rampCounter++;
    }
    else {
        rampEnable = 0;
        pc.printf("RAMP DONE\n");
    }
}

void rampSet(string data1, string data2, string data3, string data4, string data5){
    if (data1 == "STOP"){
        rampEnable = 0;
        pc.printf("RAMP STOPPED\n");
    }
    else {
        uint32_t time = stringToInteger(data5.c_str(),10,0);
        rampSteps = time/RAMPPERIOD;
        if (rampSteps > 0) {
            nozzleSteps = (atof(data1.c_str()) - dac.getOutput(NOZZLE_CH))/rampSteps;
            collectorSteps = (atof(data1.c_str()) - dac.getOutput(COLLECTOR_CH))/rampSteps;
            aux1Steps = (atof(data1.c_str()) - dac.getOutput(AUX1_CH))/rampSteps;
            aux2Steps = (atof(data1.c_str()) - dac.getOutput(AUX2_CH))/rampSteps;
            rampCounter = 0;
            rampEnable = 1;
        }
    }
}

void setHoming(string data1, string data2) {
    #if ESPINNING == 1 || ESPINNING == 2
    if (data1 == "CURR") {
        homingCurrent = atof(data2.c_str());
        pc.printf("OK\n");
    }
    else if (data1 == "POT") {
        homingPotential = atof(data2.c_str());
        pc.printf("OK\n");
    }
    else if (data1 == "EN") {
        if (data2 == "1") {
                gpio.setOutput(HOMINGPIN, 1);
                homingEn = 1;
                dac.setOutput(COLLECTOR_POT_OUT,0);
                #if ESPINNING == 1
                    dac.setOutput(AUX1_POT_OUT,0);
                    dac.setOutput(AUX2_POT_OUT,0);
                #endif
                gpio.setOutput(NOZZLE_EN_PIN, 1);      
                gpio.setOutput(COLLECTOR_EN_PIN, 1);     
                w.kick(1);
                wait(0.5);
                w.kick(WATCHDOG_TIME);
                dac.setOutput(NOZZLE_POT_OUT,HOMING_POTENTIAL);
                #if ESPINNING == 2
                    UART1.printf("G30\n"); 
                #endif
        }
        else if (data2 == "0") {
                gpio.setOutput(HOMINGPIN, 0);
                homingEn = 0;
                gpio.setOutput(NOZZLE_EN_PIN, 0);
                gpio.setOutput(COLLECTOR_EN_PIN, 0);
                dac.setOutput(NOZZLE_POT_OUT,dac.getOutput(NOZZLE_POT_OUT));
                dac.setOutput(COLLECTOR_POT_OUT,dac.getOutput(COLLECTOR_POT_OUT));
                #if ESPINNING == 1
                    dac.setOutput(AUX1_POT_OUT,dac.getOutput(AUX1_POT_OUT));
                    dac.setOutput(AUX2_POT_OUT,dac.getOutput(AUX2_POT_OUT));
                #endif
        }
        else {Error(4); return;}
        pc.printf("OK\n");
    }
    else {Error(0); return;}
    #else
        Error(0); return;
    #endif
}

void setEnv(string data1, string data2, string data3){
    bool envPin = 0;
    if      (data2 == "1")  envPin = 1;
    else if (data2 == "0")  envPin = 0;
    else                    {Error(2); return;}
    
    if (data1 == "EN") {
        if (data3 == "1")  {
            envEn[envPin] = 1; 
            if (envPin == 0) {
                gpio.setPinMode(14, 5);
                gpio.setPinMode(15, 5);
                BME280_0.initialize();
            }
            else if (envPin == 1) {
                gpio.setPinMode(16, 5);
                gpio.setPinMode(17, 5);
                BME280_0.initialize();
            }
        }
        else if (data3 == "0")  envEn[envPin] = 0;
        else                    {Error(4); return;}
        pc.printf("OK\n");
    }
    else Error("Invalid command\n");
}

void getEnv(string data1, string data2){
    bool envPin;
    if (data2 == "0") envPin = 0;
    else if (data2 == "1") envPin = 1;
    else {Error(2); return;}
    
    if (data1 == "EN") {
        pc.printf("Env En %d %d\n",envPin,envEn[envPin]);
        return;
    }
    else if (envEn[envPin] == 0) {Error("Not enabled"); return;}
    
    if (envPin == 0) {
        if (data1 == "TEMP") 
            pc.printf("Temp0: %f\n",BME280_0.getTemperature());
        else if (data1 == "HUM") 
            pc.printf("Hum0: %f\n",BME280_0.getHumidity());
        else if (data1 == "PRESS")
            pc.printf("Press0: %f\n",BME280_0.getPressure());
        else if (data1 == "ALL")
            pc.printf("Env0 All: %f %f %f\n",BME280_0.getTemperature(),BME280_0.getHumidity(),BME280_0.getPressure());
        else Error(0);
    }
    else if (envPin == 1) {
        #if ESPINNING != 3
        if (data1 == "TEMP") 
            pc.printf("Temp1: %f\n",BME280_1.getTemperature());
        else if (data1 == "HUM") 
            pc.printf("Hum1: %f\n",BME280_1.getHumidity());
        else if (data1 == "PRESS")
            pc.printf("Press1: %f\n",BME280_1.getPressure());
        else if (data1 == "ALL")
            pc.printf("Temp1: %f, Hum1: %f, Press1: %f\n",BME280_1.getTemperature(),BME280_1.getHumidity(),BME280_1.getPressure());
        else Error(0);
        #endif
    }
}

//uint8_t monitorBlinkPeriod = 1;
//gpio.setOutput(monitorOutputPin, monitorState);
bool monitorOn = 0;

void monitor(){
    for (int i=0; i<16; i++) {
        if (monitorInputEn[i])
            if ((adc.getMeasurement(i) <= monitorLower[i]) || (adc.getMeasurement(i) >= monitorUpper[i])) {
                if (monitorState > 1) monitorOn = 1;
                else gpio.setOutput(monitorOutputPin, monitorState);
                return;
            }
    }
    if (monitorState > 1) {
        monitorOn = 0;
        gpio.setOutput(monitorOutputPin, (bool)(monitorState-2));
    }
    else gpio.setOutput(monitorOutputPin, !monitorState);
}

void setMonitor(string data1, string data2, string data3, string data4, string data5){ 
    if (data1 == "EN") {
        if (stringToInteger(data2.c_str(),3,0) == 1) {
            monitorEn = 1;
            gpio.setPinMode(monitorOutputPin, 3);
        }
        else if (stringToInteger(data2.c_str(),3,0) == 0) 
            monitorEn = 0;
        else {
            Error(0); 
            return;
        }
        if (monitorState > 1) {
            gpio.setOutput(monitorOutputPin, (bool)(monitorState-2));
        }
        else gpio.setOutput(monitorOutputPin, !monitorState);
            pc.printf("OK\n");
    }
    
    else if (data1 == "OUT") {
        uint8_t pin = stringToInteger(data2.c_str(),3,1);
        if (data2[0] != 'D') {Error(2); return;}
        if (pin > 31) {
            Error(2);
            return;
        }
        monitorOutputPin = pin;
        monitorState = stringToInteger(data3.c_str(),3,0);
        monitorBlinkPeriod = stringToInteger(data4.c_str(),4,0);
        pc.printf("OK\n");
    }
    
    else if (data1 == "IN") {
        uint8_t pin = stringToInteger(data2.c_str(),3,2);
        if (data2[0] != 'A' || data2[1] != 'I') {Error(2); return;}
        if (pin > 15) {
            Error(2);
            return;
        }
        monitorInputEn[pin] = (bool)stringToInteger(data3.c_str(),3,0);
        monitorLower[pin] = atof(data4.c_str());
        monitorUpper[pin] = atof(data5.c_str());
        pc.printf("OK\n");
    }
    else Error(0);
}

void setPassThroughUART(uint8_t channel){
    if (PT_En[channel] == false) return;
    uint8_t RX_pin;
    uint8_t TX_pin;
    #if UART1_CH 
        if (channel == 1) {
            RX_pin = 8; 
            TX_pin = 9;
    #else
        if (channel == 1) {
            RX_pin = 27; 
            TX_pin = 26;
    #endif  
        UART1.baud(PT_Baud[0]);
        if (PT_Parity[0] == 0) UART1.format(PT_Length[0], SerialBase::None, PT_StopBits[0]); 
        else if (PT_Parity[0] == 1) UART1.format(PT_Length[0], SerialBase::Odd, PT_StopBits[0]); 
        else if (PT_Parity[0] == 2) UART1.format(PT_Length[0], SerialBase::Even, PT_StopBits[0]); 
        else if (PT_Parity[0] == 3) UART1.format(PT_Length[0], SerialBase::Forced1, PT_StopBits[0]); 
        else if (PT_Parity[0] == 4) UART1.format(PT_Length[0], SerialBase::Forced0, PT_StopBits[0]); 
    }
    else if (channel == 2) {
        RX_pin = 7; 
        TX_pin = 6;
        UART2.baud(PT_Baud[1]);
        if (PT_Parity[1] == 0) UART2.format(PT_Length[1], SerialBase::None, PT_StopBits[1]); 
        else if (PT_Parity[1] == 1) UART2.format(PT_Length[1], SerialBase::Odd, PT_StopBits[1]); 
        else if (PT_Parity[1] == 2) UART2.format(PT_Length[1], SerialBase::Even, PT_StopBits[1]); 
        else if (PT_Parity[1] == 3) UART2.format(PT_Length[1], SerialBase::Forced1, PT_StopBits[1]); 
        else if (PT_Parity[1] == 4) UART2.format(PT_Length[1], SerialBase::Forced0, PT_StopBits[1]);
    }
    else if (channel == 3) {
        RX_pin = 15; 
        TX_pin = 14;
        UART3.baud(PT_Baud[2]);
        if (PT_Parity[2] == 0) UART3.format(PT_Length[2], SerialBase::None, PT_StopBits[2]); 
        else if (PT_Parity[2] == 1) UART3.format(PT_Length[2], SerialBase::Odd, PT_StopBits[2]); 
        else if (PT_Parity[2] == 2) UART3.format(PT_Length[2], SerialBase::Even, PT_StopBits[2]); 
        else if (PT_Parity[2] == 3) UART3.format(PT_Length[2], SerialBase::Forced1, PT_StopBits[2]); 
        else if (PT_Parity[2] == 4) UART3.format(PT_Length[2], SerialBase::Forced0, PT_StopBits[2]);
    }
    if (PT_En[channel - 1]) {
        gpio.setPinMode(RX_pin,7);
        gpio.setPinMode(TX_pin,7);
        gpio.setReservedPin(RX_pin);
        gpio.setReservedPin(TX_pin);
    }
    else {
        gpio.clearReservedPin(RX_pin);
        gpio.clearReservedPin(TX_pin);
    }
}

void setPassThrough(string s_channel,string s_enable,string s_baud,string s_dataLength,string s_parity, string s_stopBits, string s_newLine, string s_control){
    uint8_t channel = stringToInteger(s_channel.c_str(),1,0);
    if (channel < 1 || channel > 3) {Error(1); return;}
    bool enable = stringToInteger(s_enable.c_str(),1,0);
    PT_En[channel-1] = enable;
    if (enable) {
        unsigned int baud = stringToInteger(s_baud.c_str(),6,0);
        uint8_t dataLength = stringToInteger(s_dataLength.c_str(),1,0);
        if (dataLength < 5 || dataLength > 8) {Error(4); return;}
        uint8_t parity = stringToInteger(s_parity.c_str(),1,0);
        if (parity > 4) {Error(4); return;}
        uint8_t stopBits = stringToInteger(s_stopBits.c_str(),1,0);
        if (stopBits < 1 || stopBits > 2) {Error(4); return;}
        char newLine = ' ';
        if (s_newLine == "NL") newLine = '\n';
        else if (s_newLine == "CR") newLine = '\r';
        bool control = stringToInteger(s_control.c_str(),1,0);
        
        PT_Baud[channel-1] = baud;
        PT_Length[channel-1] = dataLength;
        PT_Parity[channel-1] = parity;
        PT_StopBits[channel-1] = stopBits;
        PT_Newline[channel-1] = newLine;
        PT_Control[channel-1] = control;
    }
    
    setPassThroughUART(channel);
    //pc.printf("Ch: %d, en: %d, baud: %d, dataLength: %d, parity: %d, stopBits: %d, NL: %c, Control: %d\n",channel,enable,baud,dataLength,parity,stopBits,newLine,control);
    pc.printf("OK\n");
}



void setLink(string s_output,string s_enable,string s_input){
    bool enable;
    if (s_enable == "1") enable = true;
    else if (s_enable == "0") enable = false;
    else {Error(0); return;}
    
    if (s_output == "EN") {linkEn = enable; printOK();}
    else if (s_output[0] == 'A' && s_output[1] == 'O' && s_input[0] == 'A' && s_input[1] == 'I') {
        uint8_t output = stringToInteger(s_output.c_str(),1,2); 
        if (output > 7) {Error(1); return;}
        uint8_t input = stringToInteger(s_input.c_str(),2,2); 
        if (input > 15) {Error(1); return;}
        analogLink[output] = input;
        analogLinkEn[output] = enable;
        pc.printf("OK\n");
    }
        
    else if (s_output[0] == 'D' && s_input[0] == 'D') {
        uint8_t output = stringToInteger(s_output.c_str(),2,1); 
        if (output > 31) {Error(2); return; }
        if (gpio.getPinMode(output) != 3) {pc.printf("ERROR: Pin is no output\n"); return;}
        uint8_t input = stringToInteger(s_input.c_str(),2,1); 
        if (input > 31) {Error(2); return; }
        if (gpio.getPinMode(input) > 2) {pc.printf("ERROR: Pin is no input\n"); return;}
        digitalLink[output] = input;
        digitalLinkEn[output] = enable;
        pc.printf("DLink. output: %d, input: %d, en: %d, enLink: %d\n",output,input,enable,linkEn);
        pc.printf("OK\n");
    }
    else {Error(0); return;}
    
}

void link(){
    if (linkEn == 0) return;
    for (int i=0; i<8; i++) if (analogLinkEn[i]) dac.setOutput(i, adc.getMeasurement(analogLink[i]));  
    for (int i=0; i<31; i++) if (digitalLinkEn[i]) gpio.setOutput(i, gpio.getInput(digitalLink[i])); 
}

void setInvert(string s_pin, string s_en){
    bool en;
    if (s_en == "1") en = 1;
    else if (s_en == "0") en = 0;
    else {Error(0); return;}
    
    if (s_pin[0] != 'D') {Error(2); return;}
    uint8_t pin = stringToInteger(s_pin.c_str(),2,1); 
    if (pin > 31) {Error(2); return; }
    //pc.printf("Invert: pin %d, en: %d\n",pin,en);
    gpio.setInvert(pin,en);
    pc.printf("OK\n");
}

void messageDecoder(string data) {
    string received[10] = {"","","",""};
    int counter = 0;
    string rec = "";
    for (int i=0; i<data.length(); i++){
        char c = data[i];
        if (c == ' ') {
            received[counter] = rec;
            rec = "";
            counter++;
        }
        else
            rec += c;
    }
    received[counter] = rec;
    
    if (received[0] == "STOP") {EstopSource = 3; emergencyStop();}
    else if (received[0] == "RESET")  while(1);                 //reset by activating the watchdog
    else if (received[0] == "RAMP") rampSet(received[1],received[2],received[3],received[4],received[5]);
    else if (received[0] == "PT")   passthrough(received[1],received[2],received[3],received[4],received[5],received[6],received[7],received[8],received[9]);
    
    else if (received[0] == "GET"){
        string command = received[1];
        if (command == "ESTOP") getEstop(received[2].c_str());
        else if (EstopFlag) {
            if (command == "VER") pc.printf("\n-------------------------\n%s\nHardware version: \t%s\nSoftware version: \t%s\nSoftware date: \t\t%s\n-------------------------\n\n",NAME,HWVERSION,SWVERSION,DATE); //Get version info
            else if (command == "POT") getAnalogPot(received[2].c_str());           //Get analog potential
            else if (command == "SPAN")   getAnalogSpan(received[2].c_str());       //Get analog span
            else if (command == "CAL") getCalibration(received[2].c_str());         //Get analog calibration
            else if (command == "OVERS") getOversampling();                         //Get analog input oversampling rate
            else if (command == "BAUD") getBaud();                                  //Get serial baud rate
            else if (command == "DIN") getDigitalIn(received[2].c_str());
            else if (command == "EEPROM") getEEPROM(received[2].c_str());           //Get EEPROM settings
            else if (command == "ENV") getEnv(received[2].c_str(),received[3].c_str());                 //Get environmental sensor data
            else if (command == "SETT") getSettings();                               //Get all settings
            else if (command == "PINMODE") getPinMode(received[2].c_str()); //Get the GPIO pin mode
            else if (command == "DOUT") getDigitalOut(received[2].c_str());
            else if (command == "MULTI") getMultiUpdate(received[2].c_str(),received[3].c_str(),received[4].c_str());
            
            else pc.printf("ERROR\n");
        }
        else pc.printf("ESTOP\n");
    }
    
    else if (received[0] == "SET") {
        string command = received[1];
        if (command == "ESTOP") setEstop(received[2].c_str(),received[3].c_str(),received[4].c_str(),received[5].c_str(),received[6].c_str());
        else if (EstopFlag) {
            if (command == "POT")   setAnalogPot(received[2].c_str(),received[3].c_str());                  //Set analog output
            else if (command == "SPAN")   setAnalogSpan(received[2].c_str(),received[3].c_str());           //Set analog span
            else if (command == "DOUT") setDigitalOut(received[2].c_str(),received[3].c_str());
            else if (command == "CAL") setCalibration(received[2].c_str(),received[3].c_str(),received[4].c_str());         //Set analog calibration
            else if (command == "OVERS") setOversampling(received[2].c_str());                              //Set analog input oversampling rate
            else if (command == "BAUD") setBaud(received[2].c_str());                                       //Set serial baud rate
            else if (command == "EEPROM") setEEPROM(received[2].c_str());                                   //Set EEPROM settings
            else if (command == "PINMODE") setPinMode(received[2].c_str(),received[3].c_str());             //set the GPIO pin mode
            else if (command == "INT") setInterrupt(received[2].c_str(),received[3].c_str(),received[4].c_str(),received[5].c_str()); //set interrupt - Pin - Type
            else if (command == "MULTI") setMultiUpdate(received[2].c_str(),received[3].c_str(),received[4].c_str(),received[5].c_str());
            else if (command == "PWM")  setPWM(received[2].c_str(),received[3].c_str(),received[4].c_str());
            else if (command == "HOMING") setHoming(received[2].c_str(),received[3].c_str());
            else if (command == "ENV") setEnv(received[2].c_str(),received[3].c_str(),received[4].c_str());                 //Get environmental sensor data
            else if (command == "MONITOR") setMonitor(received[2].c_str(),received[3].c_str(),received[4].c_str(),received[5].c_str(),received[6].c_str());
            else if (command == "PT") setPassThrough(received[2].c_str(),received[3].c_str(),received[4].c_str(),received[5].c_str(),received[6].c_str(),received[7].c_str(),received[8].c_str(),received[9].c_str());
            else if (command == "LINK") setLink(received[2].c_str(),received[3].c_str(),received[4].c_str());
            else if (command == "INVERT") setInvert(received[2].c_str(),received[3].c_str());
            else if (command == "SUM") setSum(received[2].c_str(),received[3].c_str(),received[4].c_str(),received[5].c_str());
            else {Error("Invalid"); return;}
        }
        else pc.printf("ESTOP\n");
     }
     else {Error("Invalid"); return;}  
}

void messageProcess(){
    string rec = "";
    for (int i=0; i<(MESSAGE_BUFFER_SIZE+1); i++) rec+=messageBufferIncoming[i];
    newline_detected = false;
    for (int i=0; i<MESSAGE_BUFFER_SIZE ; i++) {
        messageBufferIncoming[i] = 0;
    }
    if (DEBUG) pc.printf("Received: %s\n",rec.c_str());
    messageDecoder(rec.c_str());
}

void EspinningEstop(){
    #if ESPINNING == 1
        if ((gpio.getOutput(NOZZLE_EN_PIN) || gpio.getOutput(COLLECTOR_EN_PIN || gpio.getOutput(AUX1_EN_PIN) || gpio.getOutput(AUX2_EN_PIN)) && gpio.getInput(DOORSWITCH_PIN)) {EstopSource = 4; emergencyStop();}
    #elif ESPINNING == 2
        if ((gpio.getOutput(NOZZLE_EN_PIN) || gpio.getOutput(COLLECTOR_EN_PIN)) && gpio.getInput(DOORSWITCH_PIN)) {EstopSource = 4; emergencyStop();}
    #endif
}

bool homing() {
    #if ESPINNING == 1 || ESPINNING == 2
    if (adc.getMeasurement(NOZZLE_CURR_IN) > HOMING_CURRENT || adc.getMeasurement(NOZZLE_CURR_IN) < -1*HOMING_CURRENT) {
        gpio.setOutput(HOMINGPIN, 0);
        homingEn = 0;      
        gpio.setOutput(NOZZLE_EN_PIN, 0);
        gpio.setOutput(COLLECTOR_EN_PIN, 0);       
        #if ESPINNING == 2
            w.kick(1);
            wait(0.5);
            w.kick(WATCHDOG_TIME);
            gpio.setOutput(HOMINGPIN, 1);
            UART1.printf("G91\n");
            UART1.printf("G0 Z10\n");
        #endif
        dac.setOutput(NOZZLE_POT_OUT,dac.getOutput(NOZZLE_POT_OUT));
        dac.setOutput(NOZZLE_POT_OUT,dac.getOutput(NOZZLE_POT_OUT));
        #if ESPINNING == 1
                dac.setOutput(AUX1_POT_OUT,dac.getOutput(AUX1_POT_OUT));
                dac.setOutput(AUX2_POT_OUT,dac.getOutput(AUX2_POT_OUT));
        #endif
        return 1;
    }
    #endif
    return 0;
}

#if ESPINNING == 3
Timer lcdUpdateTimer;
#define LCD_PERIOD 500
void lcdUpdate(){
    w.kick();
    string message = "Nozzle ";
    char buffer[20];
    float val;
    //lcd.setCursor(7,0);
    if (gpio.getOutput(NOZZLE_EN_PIN))  message+="EN  ";  
    else                                message+="DIS ";
    
    if (EstopTriggered) message+=" E-STOP  ";
    else {
        val = dac.getOutput(NOZZLE_POT_OUT);
        if (val > 0) message+=" ";
        if (abs(val) < 10) message+=" ";
        sprintf (buffer, "%.3fkV",val);
        message += buffer; 
    }
    lcd.setCursor(0,0);
    lcd.print(message.c_str());
    
    message=" ";
    val = adc.getMeasurement(NOZZLE_CURR_IN);
    if (val > 0) message+=" ";
    if (abs(val) < 10) message+=" ";
    sprintf (buffer, "%.3fuA ",val);
    message+=buffer; 
    val = adc.getMeasurement(NOZZLE_POT_IN);
    if (val > 0) message+=" ";
    if (abs(val) < 10) message+=" ";
    sprintf (buffer, "%.3fkV",val);
    message+=buffer;
    lcd.setCursor(0,1);
    lcd.print(message.c_str());
    
    message = "Coll   ";
    if (gpio.getOutput(COLLECTOR_EN_PIN))   message+="EN  ";  
    else                                    message+="DIS ";
    
    if (EstopTriggered) message+=" E-STOP  ";
    else {
        val = dac.getOutput(COLLECTOR_POT_OUT);
        if (val > 0) message+=" ";
        if (abs(val) < 10) message+=" ";
        sprintf (buffer, "%.3fkV",val);
        message+=buffer; 
    }  
    lcd.setCursor(0,2);
    lcd.print(message.c_str());
    
    message=" ";
    val = adc.getMeasurement(COLLECTOR_CURR_IN);
    if (val > 0) message+=" ";
    if (abs(val) < 10) message+=" ";
    sprintf (buffer, "%.3fuA ",val);
    message+=buffer; 
    val = adc.getMeasurement(COLLECTOR_POT_IN);
    if (val > 0) message+=" ";
    if (abs(val) < 10) message+=" ";
    sprintf (buffer, "%.3fkV",val);
    message+=buffer;
    lcd.setCursor(0,3);
    lcd.print(message.c_str());
    /*
    
    lcd.setCursor(7,2);
    
    
    //pc.printf("Test1\n");
    lcd.setCursor(10,0);
      
    
        
    
    lcd.setCursor(10,2);
    if (EstopTriggered) lcd.print("  E-STOP  ");
    else {
        val = dac.getOutput(COLLECTOR_POT_OUT);
        if (val > 0) lcd.print(" ");
        if (abs(val) < 10) lcd.print(" ");
        sprintf (buffer, "%.3f",val);
        lcd.print(buffer); 
    }  
    
    lcd.setCursor(0,3);
    val = adc.getMeasurement(COLLECTOR_CURR_IN);
    if (val > 0) lcd.print(" ");
    if (abs(val) < 10) lcd.print(" ");
    sprintf (buffer, "%.3f",val);
    lcd.print(buffer); 
    
    lcd.setCursor(10,3);
    val = adc.getMeasurement(COLLECTOR_POT_IN);
    if (val > 0) lcd.print(" ");
    if (abs(val) < 10) lcd.print(" ");
    sprintf (buffer, "%.3f",val);
    lcd.print(buffer);         
     */           
}

void bjornStartup(){
    
    while (gpio.getInput(12) || gpio.getInput(13)) {
        w.kick();
        lcd.setCursor(0,0); 
        lcd.print("Disable PSUs");
        lcd.setCursor(0,2);
        lcd.print("Nozzle: ");
        if (gpio.getInput(12)) lcd.print("Enabled ");
        else lcd.print("Disabled");
        lcd.setCursor(0,3);
        lcd.print("Collector: ");
        if (gpio.getInput(13)) lcd.print("Enabled ");
        else lcd.print("Disabled");
    }
    lcd.clear();
    char buffer[6];
    while(abs(adc.getMeasurement(14))>0.05 || abs(adc.getMeasurement(12))>0.05) {
        w.kick();
        lcd.setCursor(0,0); 
        lcd.print("Set output to 0V");
        lcd.setCursor(0,2);
        lcd.print("Nozzle: ");
        lcd.setCursor(10,2);
        float val = adc.getMeasurement(14);
        if (val > 0) lcd.print(" ");
        if (abs(val) < 10) lcd.print(" ");
        sprintf (buffer, "%.3f",val);
        lcd.print(buffer); 
        lcd.print(" kV");
        
        lcd.setCursor(0,3);
        lcd.print("Coll: ");
        lcd.setCursor(10,3);
        val = adc.getMeasurement(12);
        if (val > 0) lcd.print(" ");
        if (abs(val) < 10) lcd.print(" ");
        sprintf (buffer, "%.3f",val);
        lcd.print(buffer); 
        lcd.print(" kV");
        
        wait(0.001*LCD_PERIOD);
    }
    lcd.clear();
    
    /*
    lcd.setCursor(0,0);
        lcd.print("Nozzle");
        lcd.setCursor(18,0);
        lcd.print("kV");
        lcd.setCursor(18,1);
        lcd.print("kV");
        lcd.setCursor(8,1);
        lcd.print("uA");
        lcd.setCursor(0,2);
        lcd.print("Coll");
        lcd.setCursor(18,2);
        lcd.print("kV");
        lcd.setCursor(18,3);
        lcd.print("kV");
        lcd.setCursor(8,3);
        lcd.print("uA");
        */
}
#endif


/*------------------------------------------------------------------------------    
    Initialization
------------------------------------------------------------------------------*/
int main() {
    pc.baud(SerialBaud); 
    pc.printf("Startup "); 
    #if ESPINNING == 3
        gpio.setPinMode(17, 5);
        gpio.setPinMode(16, 5);
        gpio.setReservedPin(16);
        gpio.setReservedPin(17);
        lcd.begin();
        lcd.backlight();
        
    #endif
    LED = 1;                                                                   //Turn on status LED
    eeprom.initialize();                                                        //Initialize EEPROM
    EepromEn.mode(PullUp); 
    gpio.setInvertAll(0);                                                     //Set pullup mode for EEPROM jumper
    if (EepromEn == 0) loadEeprom();                                            //If EEPROM jumper is in place, load settings from EEPROM
    pc.baud(SerialBaud);                                                        //Set the Serial Baud rate
    pc.attach(&messageReceive, MODSERIAL::RxAutoDetect);                        //Attach Serial buffer
    pc.autoDetectChar('\n');                                                    //Set autodetect on end-of-line character
    adc.initialize();                                                           //Initialize ADC
    dac.initialize();                                                           //Initialize DAC
    gpio.initialize();                                                          //Initialize GPIO
    multiUpdateTimer.start();                                                   //Start the Multi update timer
    EstopTimer.start();                                                         //Start the Estop timer
    ledTimer.start();                                                           //Start the LED blink timer
    w.kick(WATCHDOG_TIME);                                                                //Set watchdog timer to 500ms
    LED = 0;                                                                    //Turn off LED to indicate initialization is ready
    if (monitorState > 1) {
        gpio.setOutput(monitorOutputPin, (bool)(monitorState-2));
    }
    else gpio.setOutput(monitorOutputPin, !monitorState);
    ledTimer.start();                                                           //Start the LED blink timer
    rampTimer.start();
    monitorTimer.start();
    monitorBlinkTimer.start();
    if (monitorEn) gpio.setPinMode(monitorOutputPin, 3);                             //Set monitor output pin to output
    setPassThroughUART(1);
    setPassThroughUART(2);
    setPassThroughUART(3);
    pc.printf("done\n");
    #if ESPINNING == 3
        gpio.setPinMode(17, 5);
        gpio.setPinMode(16, 5);
        lcdUpdateTimer.start();
        
        bjornStartup();
    #endif
    
/*------------------------------------------------------------------------------    
    Main loop
------------------------------------------------------------------------------*/
    while(1) {                                                                  
        w.kick();                                                               //Kick the watchdog awake
        
        if (monitorEn && monitorTimer.read_ms() >= 100) {
            monitor();
            monitorTimer.reset();
        }
        
        if (monitorOn && monitorBlinkTimer.read_ms() >= monitorBlinkPeriod*50){
            monitorBlinkTimer.reset();
            if (monitorState > 1) gpio.setOutput(monitorOutputPin, !gpio.getOutput(monitorOutputPin));
        }
            
        if (newline_detected) messageProcess();                                 //If Serial has received a message, analyze message
        passthroughReceive();
        checkInt();
        EstopCheck();                                                             
        if (EstopTriggered && EstopTimer.read_ms() >= EstopDelay) {
            EstopTimer.reset();
            pc.printf("ESTOP\n");   
        }

        if (homingEn == 0) {
            if (multiUpdateTimer.read_ms() >= multiUpdateInterval) { //If multi update is enabled and the trigger period has been reached...
                multiUpdateTimer.reset();                               //...reset the timer, ...
                if (EstopTriggered == false) link();                                          
                if (multiUpdateEnable[0] || multiUpdateEnable[1] ||multiUpdateEnable[2] ||multiUpdateEnable[3]) multiUpdate();    //...and run the function
                #if ESPINNING == 2
                   screenUpdate();
                #endif
                #if ESPINNING == 1 || ESPINNING == 2
                    EspinningEstop();
                #endif
                
            }
            if (rampEnable && rampTimer.read_ms() >= RAMPPERIOD){
                rampTimer.reset();
                ramp();
            }
            #if ESPINNING == 3
                if (lcdUpdateTimer.read_ms() >= LCD_PERIOD) {
                    lcdUpdateTimer.reset();
                    lcdUpdate();
                }
            #endif
        }
        if (homingEn) homing();
        
        
       
        
        if (ledTimer.read_ms() > 950 && LEDstate == 0) {                        //If LED is off and the trigger period has passed...
            LED = 1;                                                            //...turn on the LED, ...
            LEDstate = 1;                                                       //...and set flag
        }
        if (ledTimer.read_ms() > 1000 && LEDstate == 1) {                       //If LED is on and the trigger period has passed...
            LED = 0;                                                            //...turn LED off...
            LEDstate = 0;                                                       //...and reset flag...
            ledTimer.reset();                                                   //...and reset timer
            /*
            if (envEn[0] == 1) {
                temperature0 = BME280_0.getTemperature();
                humidity0 = BME280_0.getHumidity();
                pressure0 = BME280_0.getPressure();
                //pc.printf("Temp: %f, %f, %f\n",temperature,humidity,pressure);
            }
            if (envEn[1] == 1) {
                temperature1 = BME280_1.getTemperature();
                humidity1 = BME280_1.getHumidity();
                pressure1 = BME280_1.getPressure();
                //pc.printf("Temp: %f, %f, %f\n",temperature,humidity,pressure);
            }
            */
        }
    }
}
