#ifndef MAIN_H
#define MAIN_H

#include "mbed.h"
#include <string>

void messageBIN(uint16_t message);
void Error(string message);
void message(string message);
void message(float message);
void message(int message);
void message(uint32_t message);
void getAllEeprom();
void messageDecoder(string data);

#endif /* MAIN_H_ */